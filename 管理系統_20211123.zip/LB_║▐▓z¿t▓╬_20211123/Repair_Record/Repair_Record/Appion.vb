﻿Imports System.Data.OleDb

Public Class Appion

    Dim conn As OleDbConnection

    Private Sub Appion_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown

        If User_Unit = "LB_ADMIN" Then
            H_Z_Menu = Trim(InputBox("請輸入HS 或 ZK:", "請輸入廠區:"))
        End If

        If H_Z_Menu = "HS" Then
            H_Z_DBCon = HS_LB_Database
        ElseIf H_Z_Menu = "ZK" Then
            H_Z_DBCon = ZK_LB_Database
        ElseIf H_Z_Menu = "EL" Then
            H_Z_DBCon = EL_LB_Database
        ElseIf H_Z_Menu = "TEST" Then
            H_Z_DBCon = TEST_LB_Database
        End If

        Cob_FailItem.Items.Add("")
        Cob_FailItem.Items.Add("Setup Fail")
        Cob_FailItem.Items.Add("Prod Fail")
        Cob_FailItem.Items.Add("New Card")
        'Cob_FailReason.Items.Add("")
        'Cob_FailReason.Items.Add("Low Yield")
        'Cob_FailReason.Items.Add("No Pass")
        Load_HW_Table_List()

    End Sub

    Private Sub Load_HW_Table_List() '讀取HW維修派工清單

        conn = New OleDbConnection(H_Z_DBCon)
        Dim Str As String = LB_Repair_V & "where ([Verify] <> 'C')" '資料查詢表
        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
        conn.Open()
        Dim LB_Temp As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        DBST = New DataSet()
        LB_Temp.Fill(DBST, "LB_Temp") 
        'DBDT.Columns.Remove("Device") '刪除
        DBST.Tables("LB_Temp").Columns.Remove("Device") '刪除
        DBST.Tables("LB_Temp").Columns.Remove("PGM")
        DBST.Tables("LB_Temp").Columns.Remove("DownTime")
        DBST.Tables("LB_Temp").Columns.Remove("B_Count")
        DBST.Tables("LB_Temp").Columns("Fail_Reason").SetOrdinal(12)
        DataGridView1.DataSource = DBST.Tables("LB_Temp").DefaultView
        'DataGridView1.DataSource = DBDT
        'DataGridView1.Columns("ID").Visible = True '0
        DataGridView1.Columns("Date_Time").HeaderText = "Send Date"
        DataGridView1.Columns("LB_VENDOR").HeaderText = "Vendor"
        DataGridView1.Columns("Customer").HeaderText = "Customer"
        DataGridView1.Columns("Family").HeaderText = "Family"
        DataGridView1.Columns("TEST_MODE").HeaderText = "TestMode"
        DataGridView1.Columns("Stage").HeaderText = "站別"
        DataGridView1.Columns("Verify").HeaderText = "接工(Y/N)"
        ' DataGridView1.Columns("DownTime").Width = 130
        conn.Close()
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click '傳送

        Dim Str As String
        Dim PID As String = Microsoft.VisualBasic.Left(txt_Parts_ID.Text, 4)
        Dim C_B_B() As String = Split(txt_FailSite.Text, ",")
        Dim S_B_B() As String = Split(txt_FailBin.Text, ",")
        Dim R_B_B() As String = Split(Cob_FailReason.Text, ",")

        Dim S_Count As Integer = Microsoft.VisualBasic.UBound(C_B_B)

        conn = New OleDbConnection(H_Z_DBCon)

        Str = HW_Fill_Data_V & "Where Parts_ID Like '" & txt_Parts_ID.Text & "'"
        DBDA = New OleDbDataAdapter(Str, conn)
        conn.Open()
        DBDT = New DataTable
        DBDA.Fill(DBDT)
        conn.Close()

        If DBDT.Rows.Count = 0 Then
            MsgBox("NoData")
            Exit Sub
        Else
            A_Parts_ID = DBDT.Rows(0)(0).ToString 'TEXTBOX1
            A_Customer = DBDT.Rows(0)(1).ToString
            A_Family = DBDT.Rows(0)(2).ToString
            A_Site_Qty = DBDT.Rows(0)(3).ToString
            A_Tester_ID = DBDT.Rows(0)(4).ToString 'TEXTBOX2
            A_Device = DBDT.Rows(0)(5).ToString
            A_PGM = DBDT.Rows(0)(6).ToString
            A_Stage = DBDT.Rows(0)(7).ToString
        End If

        If SAME_ID_SB() = True Then
            Exit Sub
        End If
   
        If Trim(Cob_Unit.Text) = "" Or Trim(txt_Parts_ID.Text) = "" Or Trim(txt_Tester_ID.Text) = "" Or Trim(txt_FailSite.Text) = "" Or Trim(txt_FailBin.Text) = "" Or Trim(Cob_FailItem.Text) = "" Or Trim(Cob_FailReason.Text) = "" Then '空白欄位檢查跳至"ERR01"
            conn.Close()
            MessageBox.Show("請檢查空白欄位", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        Else

            If txt_Tester_ID.Text = "N/A" Then
                For n = 0 To S_Count
                    Str = "Insert Into" & Fill_Data & "(Parts_ID, Tester_ID, Customer, Family, Device, PGM, Test_Mode, Stage, Fail_Site, Fail_Bin, Fail_Item, Date_Time, Verify, LB_PID, Send_Man, Fail_Reason)Values" & _
                                                      "( '" & UCase(txt_Parts_ID.Text) & "','" & UCase(txt_Tester_ID.Text) & "', '" & A_Customer & "', '" & A_Family & "', '" & A_Device & "', '" & A_PGM & "', '" & A_Site_Qty & "', '" & A_Stage & "','" & C_B_B(n) & "','" & S_B_B(n) & "', '" & Cob_FailItem.Text & "', NOW, 'N', '" & PID & "', '" & User_ID & "', '" & R_B_B(n) & "')"
                    conn.Open()
                    Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
                    cmd.ExecuteNonQuery()
                    conn.Close()
                Next n
                MessageBox.Show("建檔完成(Add done)", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Box_Clean()
                Load_HW_Table_List()
            Else
                If txt_Tester_ID.TextLength <> 5 Then
                    conn.Close()
                    MessageBox.Show("測試機ID不可高於或低於五字元或不是N/A", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                Else
                    For n = 0 To S_Count
                        Str = "Insert Into" & Fill_Data & "(Parts_ID, Tester_ID, Customer, Family, Device, PGM, Test_Mode, Stage, Fail_Site, Fail_Bin, Fail_Item, Date_Time, Verify, LB_PID, Send_Man, Fail_Reason)Values" & _
                                                          "( '" & UCase(txt_Parts_ID.Text) & "','" & UCase(txt_Tester_ID.Text) & "', '" & A_Customer & "', '" & A_Family & "', '" & A_Device & "', '" & A_PGM & "', '" & A_Site_Qty & "', '" & A_Stage & "','" & C_B_B(n) & "','" & S_B_B(n) & "', '" & Cob_FailItem.Text & "', NOW, 'N', '" & PID & "', '" & User_ID & "', '" & R_B_B(n) & "')"
                        conn.Open()
                        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
                        cmd.ExecuteNonQuery()
                        conn.Close()
                    Next n
                    MessageBox.Show("建檔完成(Add done)", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Box_Clean()
                    Load_HW_Table_List()
                End If
            End If
        End If

        DBDT.Dispose()
        Exit Sub
        DBDT.Dispose()
    End Sub

    Private Sub txt_FailSite_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_FailSite.MouseClick
        txt_FailSite.Text = ""
        Site_Menu.Show()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click '更新
        Load_HW_Table_List()
    End Sub

    Private Sub Appion_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If OpenForm = True Then OpenForm = False : Exit Sub
        conn.Dispose()
    End Sub

    Private Sub Box_Clean()
        txt_Parts_ID.Text = ""
        txt_Tester_ID.Text = ""
        txt_FailBin.Text = ""
        txt_FailSite.Text = ""
        Cob_FailItem.Text = ""
        Cob_FailReason.Text = ""
        Cob_Unit.Text = ""
    End Sub

    Private Function SAME_ID_SB() As Boolean

        Dim searchPartsID As String = txt_Parts_ID.Text.Trim()
        Dim searchSB As String = txt_FailSite.Text.Trim()

        Dim partsIDColumn As DataGridViewColumn = DataGridView1.Columns("parts_id")
        Dim sbColumn As DataGridViewColumn = DataGridView1.Columns("Fail_Site")

        Dim matchingRows = DataGridView1.Rows.Cast(Of DataGridViewRow)().Where(Function(row) row.Cells(partsIDColumn.Index).Value IsNot Nothing AndAlso _
        row.Cells(partsIDColumn.Index).Value.ToString().Equals(searchPartsID, StringComparison.OrdinalIgnoreCase) AndAlso _
        row.Cells(sbColumn.Index).Value IsNot Nothing AndAlso row.Cells(sbColumn.Index).Value.ToString().Equals(searchSB, StringComparison.OrdinalIgnoreCase)).ToList()

        If matchingRows.Count > 0 Then
            MessageBox.Show("警告:" & txt_Parts_ID.Text & " 有尚未結案維修單,無法建立!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return True
        Else
            Return False
        End If

    End Function


End Class
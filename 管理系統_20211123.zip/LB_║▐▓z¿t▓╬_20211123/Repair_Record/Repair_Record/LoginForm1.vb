﻿Imports System.Data
Imports System.Data.OleDb
Imports ADODB

Public Class LoginForm1
    Dim Access As String = Register_Database
    Dim myCon As New ADODB.Connection
    Dim myRst As New ADODB.Recordset
    Dim IP_Addres, IP As String
    Dim DBCon As OleDbConnection

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click

        If txt_User.Text = "" Or txt_Pass.Text = "" Then
            MessageBox.Show("使用者工號 或 密碼 不得空白", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ' Exit Sub
        Else

            Try
                DBCon = New OleDbConnection(Access)
                Dim Str As String = "Select * from" & UserN & "where Name_ID like '" & txt_User.Text & "' and Name_P like '" & txt_Pass.Text & "' "
                Dim DBDA As New OleDbDataAdapter(Str, DBCon)
                DBCon.Open()
                Dim myRes As New DataTable
                DBDA.Fill(myRes)

                If myRes.Rows.Count = 0 Then
                    MessageBox.Show(" 使用者名稱或密碼錯誤 ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    txt_Pass.Text = ""
                    DBCon.Close()
                    Exit Sub
                Else

                    If (myRes.Rows(0)(4).ToString() = "USER" And myRes.Rows(0)(5).ToString() = "LB_HS") = True Then

                        User_Unit = "LB_HS"
                        H_Z_DBCon = HS_LB_Database

                    ElseIf (myRes.Rows(0)(4).ToString() = "USER" And myRes.Rows(0)(5).ToString() = "LB_ZK") = True Then

                        User_Unit = "LB_ZK"
                        H_Z_DBCon = ZK_LB_Database
                        Dut_Board = ZK_Dut_Board

                    ElseIf (myRes.Rows(0)(4).ToString() = "USER" And myRes.Rows(0)(5).ToString() = "LB_EL") = True Then

                        User_Unit = "LB_EL"
                        H_Z_DBCon = EL_LB_Database
                        Dut_Board = EL_Dut_Board

                    ElseIf (myRes.Rows(0)(4).ToString() = "USER" And myRes.Rows(0)(5).ToString() = "LB_TEST") = True Then

                        User_Unit = "LB_TEST"
                        H_Z_DBCon = TEST_LB_Database
                        Dut_Board = TEST_Dut_Board

                    ElseIf (myRes.Rows(0)(4).ToString() = "ADMIN" And myRes.Rows(0)(5).ToString() = "LB_HS") = True Then

                        User_Unit = "LB_ADMIN"
                        H_Z_DBCon = HS_LB_Database

                    ElseIf (myRes.Rows(0)(4).ToString() = "USER" And myRes.Rows(0)(5).ToString() = "CP") = True Then

                        User_Unit = "CP"

                    End If
                    DBCon.Close()
       
                End If
              

                IP_Input()

                User_ID = txt_User.Text '登錄者ID
                '記錄
                Dim Str_IP As String = "Insert Into" & Register_Date_Table & "(User_ID, IP_Addres, Version, Inster_Date)Values" & _
                   "( '" & txt_User.Text & "','" & IP_Addres & "','" & Version & "', '" & Now & "')"

                DBCon = New OleDbConnection(Access)
                DBCon.Open()
                Dim cmd As OleDbCommand = New OleDbCommand(Str_IP, DBCon)

                '執行資料庫指令OleDbCommand
                cmd.ExecuteNonQuery()
                Me.Hide()
                'myCon.Close()
                'Home_Screen.Show() '主畫面
                Home_Screen.Show()
                'cmd.Dispose()
                DBCon.Close()
                'DBCon.Dispose()

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

        End If


        Exit Sub

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        LoginForm2.Show()
        Me.Hide()
    End Sub

    Private Sub IP_Input()
        Dim HostName As String = System.Net.Dns.GetHostName

        For Each item As System.Net.IPAddress In System.Net.Dns.GetHostEntry(HostName).AddressList
            IP = item.ToString
        Next

        IP_Addres = IP

    End Sub

    Private Sub LoginForm1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        myCon = New Connection
        myCon.Open(Access)
        myRst = New Recordset

        Dim strql As String = "Select * from" & Ver_Table & "where Ver like '" & Version & "'"

        myRst = myCon.Execute(strql)

        If myRst.EOF = True Then
            MessageBox.Show(" 此版本為舊版本，請更新! ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            myCon.Close()
            Me.Close()
        Else
            myCon.Close()
        End If

    End Sub

End Class


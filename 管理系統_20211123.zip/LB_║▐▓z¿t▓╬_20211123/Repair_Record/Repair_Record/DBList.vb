﻿Module DBList

    'Public path As String = "D:\"

    'Register 
    Public HS_Path As String = "\\NAS27\LB-Repair-Room\02 系統資料\04_維修管理系統\HS\" '登錄各廠區資料庫
    Public ZK_Path As String = "\\NAS27\LB-Repair-Room\02 系統資料\04_維修管理系統\ZK\"
    Public EL_Path As String = "\\NAS27\LB-Repair-Room\02 系統資料\04_維修管理系統\EL\"
    Public TEST_Path As String = "\\NAS27\LB-Repair-Room\02 系統資料\04_維修管理系統\TEST\" '測試檔案
    Public Public_Path As String = "\\NAS27\LB-Repair-Room\02 系統資料\04_維修管理系統\" '帳號密碼登錄資料庫路徑

    '本機測試
    'Public TEST_Path As String = "D:\spil_data\LB_20211123\LB_管理系統_20211123\TEST\" '測試檔案
    'Public Public_Path As String = "D:\spil_data\LB_20211123\LB_管理系統_20211123\" '帳號密碼登錄資料庫路徑


    Public Register_Database As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Public_Path & "Register_Database.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"
    Public ComList_Database As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Public_Path & "ComList.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"

    Public HS_LB_Database As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & HS_Path & "HS_LB_Database.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"
    Public Componet_DataBase As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Public_Path & "Com_Tool.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"

    Public Dut_Board As String

    Public ZK_LB_Database As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & ZK_Path & "ZK_LB_Database.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"
    Public ZK_Dut_Board As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & ZK_Path & "Dut_Board.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"

    Public EL_LB_Database As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & EL_Path & "EL_LB_Database.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"
    Public EL_Dut_Board As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & EL_Path & "Dut_Board.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"

    Public TEST_LB_Database As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & TEST_Path & "LB_Database.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"
    Public TEST_Dut_Board As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & TEST_Path & "Dut_Board.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"

    ' Public Register_Database As String = "Provider=Microsoft.ACE.Oledb.12.0;" & _
    '                                 "Data Source=" & Public_Path & "Register_Database.accdb;" & _
    '                                 "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True"

    'Public HS_LB_Database As String = "Provider=Microsoft.ACE.Oledb.12.0;" & _
    '                                  "Data Source=" & HS_Path & "HS_LB_Database.accdb;" & _
    '                                  "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True"

    'Public ZK_LB_Database As String = "Provider=Microsoft.ACE.Oledb.12.0;" & _
    '                                  "Data Source=" & ZK_Path & "ZK_LB_Database.accdb;" & _
    '                                  "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True"

    'Public Dut_Board As String = "Provider=Microsoft.ACE.Oledb.12.0;" & _
    '                                  "Data Source=" & ZK_Path & "Dut_Board.accdb;" & _
    '                                  "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True"

    'Public EL_LB_Database As String = "Provider=Microsoft.ACE.Oledb.12.0;" & _
    '                                 "Data Source=" & EL_Path & "ZK_LB_Database.accdb;" & _
    '                                 "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True"

    'Public EL_Dut_Board As String = "Provider=Microsoft.ACE.Oledb.12.0;" & _
    '                                  "Data Source=" & EL_Path & "Dut_Board.accdb;" & _
    '                                  "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True"


    'Public Componet_DataBase As String = "Provider=Microsoft.ACE.Oledb.12.0;" & _
    '                            "Data Source=" & Public_Path & "Com_Tool.accdb;" & _
    '                            "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=False"

    'Public TEST_LB_Database As String = "Provider=Microsoft.ACE.Oledb.12.0;" & _
    '                                 "Data Source=" & TEST_Path & "LB_Database.accdb;" & _
    '                                 "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True"

    'Public TEST_Dut_Board As String = "Provider=Microsoft.ACE.Oledb.12.0;" & _
    '                                  "Data Source=" & TEST_Path & "Dut_Board.accdb;" & _
    '                                  "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True"



    Public Ver_Table As String = " Ver_Table "
    Public UserN As String = " UserName "
    Public Register_Date_Table As String = " Register_Date "

    Public RV_ID, RV_DATETIME, RV_PARTS_ID, RV_TESTER_ID, RV_VENDOR, RV_CUSTOMER, RV_FAMILY, RV_DEVICE, RV_PGM, RV_TESTMODE, RV_STATUS, RV_FailSite, RV_FailBin, RV_FailReason, RV_FailItem, RV_STAGE, RV_Verify, RV_DownTime, RV_Send_Man, RV_B_Count As String
    Public RFL_ID_N As String


    Public LB_Repair_V As String = "Select * from PLB_Repair_List_V " '派工 資料查詢表


    Public Fill_Data As String = " Fill_Fail_Data "  '派工 資料寫入
    Public Repair_Fill_List_Table As String = " Repair_Fill_List " '接工 資料寫入


    Public Repair_Fill_Data As String = " Repair_Data " '完工 無用資料表

    Public Repair_Fill_Temp As String = " Repair_Temp " '暫存 無用資料表


    Public HW_Fill_Data_V As String = " Select * from HW_Fill_Data_V "

    Public Fill_Fail_Data As String = "Select * from Fill_Fail_Data "

    Public Repair_Done_List_V_Table As String = " Repair_Done_List_V "

    Public HW_Fill_Data_PLB_Table As String = " HW_Fill_Data_PLB "


    Public COMP_SPIL_No_V, COMP_Vendor_Name_V, COMP_Vendor_No_V, COMP_Customer_V, COMP_Family_V, COMP_Kind_V As String
    Public COMP_Type_V, COMP_Provider_V, COMP_Creator_Date_V, COMP_Location_V, COMP_Creator_V As String

    Public COMP_Description_V, COMP_Image_ID_V, COMP_Str, Change_Parts_List As String


    Public Comp_ID As Long
    Public Comp_QTY As Long
    Public QTY As Integer
    Public Consume_QTY As Long
    Public Lev_PID As String
    Public DA_V As String

    '數字敘述
    Public ID_W As Long
    Public Received_QTY As Integer
    Public ID_N_W As Double
    Public COMP_ID_V As Double

    'Public COMP_QTY As Integer

    Public COMP_Spare_Qty_V As Integer
    Public COMP_ID_W As Double
    Public Lev_N As Integer

    Public txtReason As String
    Public Arr_Attribute(50) As String


End Module

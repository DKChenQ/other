﻿#!/usr/bin/python
# -*- coding: utf-8 -*-

import csv
import os 
#import xlrd
import xlwt
import pyodbc

import pyexcel as p
from win32com.client import Dispatch

xlapp = Dispatch('Excel.Application')
file_path = r'F:\procard_py\excel\PC_Status.xls'

conString = r'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=E:\Repair_Success_Rate.accdb;'
conn = pyodbc.connect(conString)

SQL = "TRANSFORM Last(EUC_E4_PMS_PART_DETAIL_V.COLUMN_VALUE) AS COLUMN_VALUE" +\
" SELECT EUC_E4_PMS_PART_BASIC_V.PART_NO, EUC_E4_PMS_PART_BASIC_V.PART_TYPE, EUC_E4_PMS_PART_BASIC_V.STATUS_DESC, EUC_E4_PMS_PART_BASIC_V.LOCATION_NO, EUC_E4_PMS_PART_BASIC_V.LAST_UPDATE_TIME, EUC_E4_PMS_PART_BASIC_V.ETL_LOAD_DATE, MID(EUC_E4_PMS_PART_BASIC_V.SITE_NO,1,2) AS AREA" +\
" FROM EUC_E4_PMS_PART_BASIC_V INNER JOIN EUC_E4_PMS_PART_DETAIL_V ON EUC_E4_PMS_PART_BASIC_V.PART_NO = EUC_E4_PMS_PART_DETAIL_V.PART_NO" +\
" WHERE (((EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME) Like 'PROBEHEAD_NO' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='CUSTOMER' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='FAMILY' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='DEVICE' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TEST_MODE' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TESTER_PLATFORM' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='NO' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='BEFORE_PART_NO' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='VENDOR' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='VENDOR_NO' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='PROCARD_TYPE' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='RECEIVE_TIME' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='RELEASED_DATE' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='DIAMETER_TYPE' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TIP_DIAMETER' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TIP_DIAMETER_SPEC' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TIP_LENGTH' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TIP_LEN_SPEC' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TIP_LENGTH_AVERAGE' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TIP_PCB' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TIP_PCB_DEPTH_SPEC' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TOTAL_TOUCH_DOWN' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TOUCH_MAINTAIN_SPEC' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='CURRENT_TOUCH_DOWN' Or (EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME)='TD_UPDATE_DATE') AND ((EUC_E4_PMS_PART_BASIC_V.PART_CATEGORY) Like 'PROBECARD') AND ((EUC_E4_PMS_PART_BASIC_V.STATUS_DESC)<>'S' And (EUC_E4_PMS_PART_BASIC_V.STATUS_DESC)<>'RC' And (EUC_E4_PMS_PART_BASIC_V.STATUS_DESC)<>'SHIP') AND ((EUC_E4_PMS_PART_BASIC_V.SITE_NO) Like 'HS%' Or (EUC_E4_PMS_PART_BASIC_V.SITE_NO)='ZK' Or (EUC_E4_PMS_PART_BASIC_V.SITE_NO)='ZX'))" +\
" GROUP BY EUC_E4_PMS_PART_BASIC_V.PART_NO, EUC_E4_PMS_PART_BASIC_V.PART_CATEGORY, EUC_E4_PMS_PART_BASIC_V.PART_TYPE, EUC_E4_PMS_PART_BASIC_V.STATUS_DESC, EUC_E4_PMS_PART_BASIC_V.LOCATION_NO, EUC_E4_PMS_PART_BASIC_V.LAST_UPDATE_TIME, EUC_E4_PMS_PART_BASIC_V.ETL_LOAD_DATE, EUC_E4_PMS_PART_BASIC_V.SITE_NO" +\
" PIVOT EUC_E4_PMS_PART_DETAIL_V.COLUMN_NAME"


cur = conn.cursor()
cur.execute(SQL)

#records = cur.fetchone() #列印一筆
#print("Parts_id:", records) 
#print(records[1])

#data = cur.fetchall() #列印全部
#print("Parts_id:", data[1])
#print(data)

# OPEN CSV AND ITERATE THROUGH RESULTS
with open('F:\procard_py\PC_Status.csv', 'w', encoding="utf-8", newline='' )as f: #+b移除空格 encoding='utf-8'
    writer = csv.writer(f) 
    writer.writerow(("Parts_ID", "Vertical_TYPE", "STATUS", "LOCATION", "Last_Use_Date", "ETL_LOAD_DATE", "SITE_NO", "B_PART_NO", "CURRENT_TOUCH_DOWN", "CUSTOMER", "DEVICE", "DIAMETER_TYPE", "FAMILY", "NO" +'\t', "PROBEHEAD_ID", "PROCARD_TYPE", "RECEIVE_TIME", "RELEASED_DATE", "TD_UPDATE_DATE", "Site_QTY", "TESTER_PLATFORM", "TIP_DIAMETER", "TIP_DIAMETER_SPEC", "TIP_LEN_SPEC", "TIP_LEN", "TIP_LENGTH_AVERAGE", "TIP_PCB", "TIP_PCB_DEPTH_SPEC", "Total_TD", "TOUCH_MAINTAIN_SPEC", "VENDOR", "VENDOR_NO"))  
    for row in cur.fetchall():  
        writer.writerow(row)



cur.close()
conn.close()

# 存檔成xls
#p.save_book_as(file_name='d:\PC_Status.csv',  dest_file_name='d:\PC_Status.xls')


csvfiles = os.listdir('.')
csvfiles = filter(lambda x: x.endswith('csv'), csvfiles)
for csvfile in list(csvfiles):
    finename = csvfile.split('.')[0]
    if not os.path.exists('excel'):
        os.mkdir('excel')
xlsfile = 'excel/' + finename + '.xls'
with open(csvfile, 'r', encoding="utf-8", newline='') as f:
    reader = csv.reader(f)
    workbook = xlwt.Workbook()
    sheet = workbook.add_sheet('PC_Status.csv') #創建一個工作表
    i = 0
    for line in reader:
        j = 0
        for v in line:
            sheet.write(i, j, v)
            j += 1
        i += 1
    workbook.save(xlsfile) #儲存EXCEL
print(f'轉換完成: {csvfile} -> {xlsfile}')


# 打開excel
xlbook = xlapp.Workbooks.Open(file_path,False)

xlbook.Close()
xlapp.Quit()

# -*- coding: utf-8 -*-
import sys
import pyodbc
from PyQt5.QtWidgets import QApplication, QMainWindow, QComboBox, QLabel, QPushButton, QTableWidget, QTableWidgetItem, QCheckBox, QGraphicsLineItem
#from PyQt5.QtChart import QChart, QChartView, QLineSeries
#from PyQt5.QtGui import QPainter,QFont,QPen,QColor
from PyQt5.QtGui import *
from PyQt5.QtCore import Qt,QRect,QLineF
from PyQt5 import QtCore, QtGui, QtWidgets, QtChart
from PyQt5.QtChart import *

class Ui_MainWindow(object):
    def __init__(self):
        super().__init__()


    def closeEvent(self, event):
        # 視窗關閉時關閉資料庫連接
        self.conn.close()
        event.accept()

    def setupUi(self, MainWindow):

        # 連接Access資料庫
        self.conn = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=F:\2023_LoadBoard_專用資料\ZK維修轉換\QCT_DataBase.accdb;Uid=Admin;Pwd=;')
        self.cursor = self.conn.cursor()

        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1090, 850)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(40, 40, 91, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(200, 40, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(340, 40, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(560, 40, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(40, 100, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_5.setFont(font)
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(200, 100, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_6.setFont(font)
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(340, 100, 131, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_7.setFont(font)
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(560, 100, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_8.setFont(font)
        self.label_8.setObjectName("label_8")
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(700, 100, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_9.setFont(font)
        self.label_9.setObjectName("label_9")
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(840, 100, 101, 31))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.label_10.setFont(font)
        self.label_10.setObjectName("label_10")

        self.comboBox_1 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_1.setGeometry(QtCore.QRect(40, 70, 151, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_1.setFont(font)
        #self.comboBox_1.setStyleSheet("background-color: white;")
        # 設定下拉選單箭頭的顏色
        #self.comboBox_1.setStyleSheet("QComboBox::down-arrow { image: url(r.png); }")
        self.comboBox_1.setObjectName("comboBox")

        self.comboBox_2 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_2.setGeometry(QtCore.QRect(200, 70, 131, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_2.setFont(font)
        self.comboBox_2.setObjectName("comboBox_2")

        self.comboBox_3 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_3.setGeometry(QtCore.QRect(340, 70, 211, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_3.setFont(font)
        self.comboBox_3.setObjectName("comboBox_3")
        self.comboBox_4 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_4.setGeometry(QtCore.QRect(560, 70, 131, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_4.setFont(font)
        self.comboBox_4.setObjectName("comboBox_4")
        self.comboBox_5 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_5.setGeometry(QtCore.QRect(40, 130, 151, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_5.setFont(font)
        self.comboBox_5.setObjectName("comboBox_5")
        self.comboBox_6 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_6.setGeometry(QtCore.QRect(200, 130, 131, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_6.setFont(font)
        self.comboBox_6.setObjectName("comboBox_6")
        self.comboBox_7 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_7.setGeometry(QtCore.QRect(340, 130, 211, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_7.setFont(font)
        self.comboBox_7.setObjectName("comboBox_7")
        self.comboBox_8 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_8.setGeometry(QtCore.QRect(560, 130, 131, 21))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_8.setFont(font)
        self.comboBox_8.setObjectName("comboBox_8")
        self.comboBox_9 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_9.setGeometry(QtCore.QRect(700, 130, 131, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_9.setFont(font)
        self.comboBox_9.setObjectName("comboBox_9")
        self.comboBox_10 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_10.setGeometry(QtCore.QRect(840, 130, 221, 22))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.comboBox_10.setFont(font)
        self.comboBox_10.setObjectName("comboBox_10")

        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(830, 60, 131, 41))
        font = QtGui.QFont()
        font.setFamily("Arial")
        font.setPointSize(12)
        self.pushButton.setFont(font)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("search.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton.setIcon(icon1)
        self.pushButton.setIconSize(QtCore.QSize(32, 32))
        self.pushButton.setObjectName("pushButton")

        self.graphicsView = QChartView(self.centralwidget)
        self.graphicsView.setGeometry(QtCore.QRect(40, 170, 1021, 251))
        self.graphicsView.setObjectName("graphicsView")
        MainWindow.setCentralWidget(self.centralwidget)

        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1091, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        # 創建 QTableWidget 控制項
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setGeometry(QtCore.QRect(40, 430, 1021, 371))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.itemSelectionChanged.connect(self.update_chart)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        # 將資料庫引入到TABLE裡
        self.cursor.execute("SELECT * FROM Weekly_P")
        data = self.cursor.fetchall()
        self.populate_table(data)

        self.conn.close() #關閉資料庫

        self.pushButton.clicked.connect(self.search_database) #搜尋按鈕


    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowIcon(QtGui.QIcon('kite.png'))
        MainWindow.setWindowTitle(_translate("MainWindow", "HEALTH RATE WEEKLY TREND - LOADBOARD"))
        self.label.setText(_translate("MainWindow", "Report Year"))
        self.label_2.setText(_translate("MainWindow", "Report Month"))
        self.label_3.setText(_translate("MainWindow", "Device Name"))
        self.label_4.setText(_translate("MainWindow", "SAT"))
        self.label_5.setText(_translate("MainWindow", "STATUS"))
        self.label_6.setText(_translate("MainWindow", "DUT"))
        self.label_7.setText(_translate("MainWindow", "Production Line"))
        self.label_8.setText(_translate("MainWindow", "VENDOR"))
        self.label_9.setText(_translate("MainWindow", "Location"))
        self.label_10.setText(_translate("MainWindow", "Package Type"))
        self.pushButton.setText(_translate("MainWindow", "搜尋"))

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT Format([CH_DATE],'yyyy') as Y_Date FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_1.addItem('(ALL)')
        for row in results:
            self.comboBox_1.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT Format([CH_DATE],'m') as M_Date FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_2.addItem('(ALL)')
        for row in results:
            self.comboBox_2.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [Device_Name] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_3.addItem('(ALL)')
        for row in results:
            self.comboBox_3.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [SAT] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_4.addItem('(ALL)')
        for row in results:
            self.comboBox_4.addItem(row[0])

         # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [STATUS] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_5.addItem('(ALL)')
        for row in results:
            self.comboBox_5.addItem(row[0])

         # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [DUT] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_6.addItem('(ALL)')
        for row in results:
            self.comboBox_6.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [Tester_Platform] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_7.addItem('(ALL)')
        for row in results:
            self.comboBox_7.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [VENDOR] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_8.addItem('(ALL)')
        for row in results:
            self.comboBox_8.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [Location] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_9.addItem('(ALL)')
        for row in results:
            self.comboBox_9.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [PACKAGE_TYPE] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        self.comboBox_10.addItem('(ALL)')
        for row in results:
            self.comboBox_10.addItem(row[0])

    def populate_table(self, data): #寫入Table
        # 設定表格欄位名稱--手動添加
        columns = [column[0] for column in self.cursor.description]
        ##columns = ['Device_Name','WeekNumber']

        # 設定表格欄位樣式
        header = self.tableWidget.horizontalHeader()
        header.setStyleSheet("QHeaderView::section {background-color: rgb(30, 138, 138); color: white; font-weight: bold;}")
        header.setHighlightSections(False)

        # 設定表格大小為資料表大小
        self.tableWidget.setColumnCount(len(columns))
        self.tableWidget.setHorizontalHeaderLabels(columns)
        self.tableWidget.setRowCount(len(data))
        #self.tableWidget.setColumnHidden(0, True) # 隱藏第0欄

        # 將資料寫入表格
        for row in range(len(data)):
            for col in range(len(data[0])):
                item = QtWidgets.QTableWidgetItem(str(data[row][col]))
                self.tableWidget.setItem(row, col, item)
                item.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter) #文字置中

    def update_chart(self):
        # 取得當前選擇的行列
        items = self.tableWidget.selectedItems()
        firstColumnItems = [item for item in items if item.column() == 0]
        if not items:
          return
        row = items[0].row()
        col = items[0].column()

           # 取得所有欄位名稱
        labels = []
        for i in range(self.tableWidget.columnCount()):
             item = self.tableWidget.horizontalHeaderItem(i)
             labels.append(item.text())
        #print(labels[0])

        # 取得選擇的行的所有數值
        data = []
        for i in range(1,self.tableWidget.columnCount()):
            item = self.tableWidget.item(row, i)
            data.append(item.text())
        data_float = [float(d.strip('%')) for d in data]

        cname = []
        for i in range(self.tableWidget.columnCount()):
            item = self.tableWidget.item(row, i)
            cname.append(item.text())

        Device_name = cname[0]

        # 創建數據序列
        series = QLineSeries()
        scatter = QScatterSeries()

        # 添加數據點
        for i in range(len(data_float)):
            series.append(i+1, float(data_float[i]))
            scatter.append(i+1, float(data_float[i]))

        # 創建圖表並添加數據序列
        self.chart = QChart()

        # 顯示/背景顏色
        self.chart.setBackgroundVisible(True)
        #self.chart.setBackgroundBrush(QBrush(QColor(30,150,155)))

        # 將 LineSeries 添加到圖表中
        self.chart.removeAllSeries()
        self.chart.addSeries(series)
        self.chart.addSeries(scatter)

        # 創建 X 軸和 Y 軸
        xaxis = QCategoryAxis()
        yaxis = QValueAxis()

        # 將欄位名稱添加到 X 軸
        for i in range(len(labels)):
         if (i==0):{}
         else: {
         xaxis.append(labels[i],i)}

        # 設置 X 軸的範圍和標籤
        #xaxis.setLabelFormat("%d")
        #xaxis.setTickCount(0)
        #xaxis.setMinorTickCount(0)
        xaxis.setRange(0, len(labels))
        xaxis.setLabelsPosition(QCategoryAxis.AxisLabelsPositionOnValue)
        xaxis.setTitleText("Week")
        xaxis.setLabelsVisible(True)

        # 設置 Y 軸範圍
        yaxis.setLabelFormat("%.2f%")
        yaxis.setTickCount(3)
        yaxis.setMinorTickCount(4)
        yaxis.setRange(0, 120)
        yaxis.setTitleText("Yield %")

        # 將 X 軸添加到圖表中
        self.chart.addAxis(xaxis, Qt.AlignBottom)
        series.attachAxis(xaxis)
        scatter.attachAxis(xaxis)

        # 將 Y 軸添加到圖表中
        self.chart.addAxis(yaxis, Qt.AlignLeft)
        series.attachAxis(yaxis)
        scatter.attachAxis(yaxis)

        # 設置圖表標題
        #self.chart.setTitle("Weekly Quantity")
       # self.chart.setTheme(QChart.ChartThemeBrownSand)
       # self.chart.setTheme(QChart.ChartThemeHighContrast)
       # self.chart.setTheme(QChart.ChartThemeBlueCerulean)
       # self.chart.setTheme(QChart.ChartThemeLight)
       # self.chart.setTheme(QChart.ChartThemeDark)

        # 設置折線圖的線條顏色和名稱
        pen = QPen()
        pen.setWidth(2)
        pen.setColor(QColor(0, 150, 200))
        series.setPen(pen)
        series.setName(Device_name)
        #series.setPointLabelsVisible(True)
        #series.setPointLabelsColor(QColor(32, 78, 152))
        #series.setPointLabelsFormat("@yPoint%") #標記數值

        # 設置數據點標記的大小和樣式
        scatter.setVisible(True)
        scatter.setMarkerSize(6)
        scatter.setMarkerShape(QScatterSeries.MarkerShapeRectangle) #圖標形狀
        scatter.setColor(QColor(0, 150, 200))
        scatter.setPointLabelsVisible(True)
        scatter.setPointLabelsColor(QColor(32, 78, 152))
        scatter.setPointLabelsFormat("@yPoint%") #標記數值

        # 隱藏散點圖的圖例
        marker = self.chart.legend().markers(scatter)[0]
        marker.setVisible(False)

        series2 = QLineSeries()
        series2.setName("Standard line")
        series2.setVisible(True)
        pen2 = QPen(QColor(0, 180, 80),1.5, Qt.DashLine)
        series2.setPen(pen2)
        for i in range(12):
            x = i * 3
            y = 90
            series2.append(x, y)
        self.chart.addSeries(series2)
        series2.attachAxis(yaxis)

        # 設置圖表視圖的屬性和添加圖表到視圖
        self.graphicsView.setRenderHint(QPainter.Antialiasing)
        self.graphicsView.setRenderHint(QPainter.HighQualityAntialiasing)
        self.graphicsView.setRenderHint(QPainter.SmoothPixmapTransform)
        self.graphicsView.setChart(self.chart)

    def search_database(self):

        self.conn = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=F:\2023_LoadBoard_專用資料\ZK維修轉換\QCT_DataBase.accdb;Uid=Admin;Pwd=;')
        self.cursor = self.conn.cursor()
        c3_value = self.comboBox_3.currentText()
        #print(c3_value)
        query = "SELECT * FROM Weekly_P WHERE Device_Name LIKE ?"
        params = (f"{c3_value}")
        self.cursor.execute(query, params )
        data = self.cursor.fetchall()
        self.populate_table(data)
        self.conn.close() #關閉資料庫
        self.update_chart()

if __name__ == "__main__":

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

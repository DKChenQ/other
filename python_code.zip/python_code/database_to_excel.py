#!/usr/bin/python
# -*- coding: utf-8 -*-

import pyodbc
import pandas as pd

conn = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=F:\2023_LoadBoard_專用資料\CIM.accdb;')


query = 'SELECT * FROM CIM_DATA_TABLE'
df = pd.read_sql(query, conn)

df.to_excel('d:\table1.xlsx', index=False)



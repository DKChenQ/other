from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QPushButton, QLineEdit, QMenuBar, QMenu, QAction, QTableWidget, QTableWidgetItem
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setGeometry(100, 100, 800, 600)
        self.setWindowTitle("LB_Room_專用")

        # 創建 QLabel 控制項
        self.label = QLabel(self)
        self.label.setGeometry(50, 50, 80, 30)
        self.label.setText("Family: ")
        self.label.setFont(QFont("Arial", 12, QFont.Thin))


        # 創建 QLineEdit 控制項
        self.lineedit = QLineEdit(self)
        self.lineedit.setGeometry(105, 50, 100, 30)

        # 創建 QPushButton 控制項
        self.button = QPushButton(self)
        self.button.setGeometry(210, 50, 100, 30)
        self.button.setText("搜尋")

        # 創建 QTableWidget 控制項
        self.table_widget = QTableWidget(self)
        self.table_widget.setGeometry(300, 300, 400, 200)
        self.table_widget.setColumnCount(2)
        self.table_widget.setRowCount(3)

        # 設置表頭
        self.table_widget.setHorizontalHeaderLabels(["姓名", "年齡"])

        # 設置表格內容
        self.table_widget.setItem(0, 0, QTableWidgetItem("小明"))
        self.table_widget.setItem(0, 1, QTableWidgetItem("18"))
        self.table_widget.setItem(1, 0, QTableWidgetItem("小紅"))
        self.table_widget.setItem(1, 1, QTableWidgetItem("20"))
        self.table_widget.setItem(2, 0, QTableWidgetItem("小強"))
        self.table_widget.setItem(2, 1, QTableWidgetItem("22"))

        # 為 QTableWidget 控制項增加上下文菜單
        self.table_widget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table_widget.customContextMenuRequested.connect(self.show_context_menu)

    def show_context_menu(self, pos):
        menu = QMenu(self.table_widget)
        copy_action = QAction("複製", self)
        cut_action = QAction("剪下", self)
        paste_action = QAction("貼上", self)
        menu.addAction(copy_action)
        menu.addAction(cut_action)
        menu.addAction(paste_action)
        action = menu.exec_(self.table_widget.mapToGlobal(pos))

        if action == copy_action:
            selected_text = self.table_widget.selectedItems()[0].text()
            QApplication.clipboard().setText(selected_text)
        elif action == cut_action:
            selected_text = self.table_widget.selectedItems()[0].text()
            QApplication.clipboard().setText(selected_text)
            self.table_widget.setItem(self.table_widget.currentRow(), self.table_widget.currentColumn(), QTableWidgetItem(""))
        elif action == paste_action:
            paste_text = QApplication.clipboard().text()
            self.table_widget.setItem(self.table_widget.currentRow(), self.table_widget.currentColumn(), QTableWidgetItem(paste_text))

if __name__ == "__main__":
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()

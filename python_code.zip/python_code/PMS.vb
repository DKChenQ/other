Imports System.Data
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Imports ADODB
Imports System.IO

Public Class Form1

    Dim sql As String '= "Provider=Microsoft.ACE.Oledb.12.0;Data Source=\\nas27\Probe-Card\日常管理文件櫃\03_電子系統存放區\PMS_Status.accdb;User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True"
    Dim str As String
    Dim strline, PATH_APP As String
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'On Error Resume Next

        Shell("cmd /c mkdir c:\Roy_MD")
        delay()
        Shell("cmd /c COPY \\nas27\Probe-Card\日常管理文件櫃\04_程式安裝存放區\PMS_Status\Release\PMS_Status.txt C:\Roy_MD")
        delay()

        Dim sr As StreamReader = New StreamReader("C:\Roy_MD\PMS_Status.txt", System.Text.Encoding.Default)

        ' Dim sr As StreamReader = New StreamReader("C:\Roy_MD\123.txt", System.Text.Encoding.Default)

        Do
            '讀下一行
            strline = sr.ReadLine()
            '將所讀入的字串，依照 , 來拆解到陣列上
            ' strelement = strline.Split(",")
            '將將第1, 2欄位拆解出
            'RichTextBox1.Text &= strelement(0) & vbTab & vbTab & strelement(1) & vbNewLine
            PATH_APP = strline

        Loop While (sr.Peek() <> -1) '若讀到最尾端的資料，則sr.Peek() = -1

        'sql = "Provider=Microsoft.ACE.Oledb.12.0;Data Source=" & PATH_APP & "PC_Data.accdb;User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True"
        sql = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & PATH_APP & "PC_Data.mdb;User Id=admin;Jet OLEDB:Database Password=s967132;Persist Security Info=False"


        ver()

        Me.Text = "PMS 查詢"
        Me.WindowState = FormWindowState.Maximized
        'Me.ControlBox = False
        Me.GroupBox1.Text = ""
        ' Me.GroupBox2.Text = ""
        Me.RadioButton1.Text = "Family"
        Me.RadioButton2.Text = "Parts_ID"
        Me.Label3.Text = "Vertical_Type"


        Me.Label1.Text = "Status"
        Me.Label2.Text = "Family"
        Me.Label4.Text = "Site_Qty"
        Me.Label5.Text = "Site.No:"
        Me.Button1.Text = ""
        Me.Button2.Text = ""
        Me.Button3.Text = ""
        Me.ComboBox5.Items.Add("HS")
        Me.ComboBox5.Items.Add("TC")
        Me.CheckBox1.Text = "模糊搜尋"
        Me.CheckBox2.Text = "生產機台查詢"
        Me.RadioButton1.Checked = True
        Me.TextBox1.Visible = False

        'On Error GoTo err

        Dim conn As OleDbConnection = New OleDbConnection(sql)

        str = " Select DISTINCT Family from PC_Status"
        Dim adp As OleDbDataAdapter = New OleDbDataAdapter(str, conn)
        conn.Open()
        Dim set1 As DataSet = New DataSet
        adp.Fill(set1, "#1")

        ComboBox2.DataSource = set1.Tables("#1")
        ComboBox2.ValueMember = "Family"
        conn.Close()

        str = " Select DISTINCT Status from PC_Status"
        Dim adp1 As OleDbDataAdapter = New OleDbDataAdapter(str, conn)
        conn.Open()
        Dim set2 As DataSet = New DataSet
        adp1.Fill(set2, "#1")

        ComboBox1.DataSource = set2.Tables("#1")
        ComboBox1.ValueMember = "Status"

        conn.Close()

        str = " Select DISTINCT Vertical_Type from PC_Status"
        Dim adp2 As OleDbDataAdapter = New OleDbDataAdapter(str, conn)
        conn.Open()
        Dim set3 As DataSet = New DataSet
        adp2.Fill(set3, "#1")

        ComboBox3.DataSource = set3.Tables("#1")
        ComboBox3.ValueMember = "Vertical_Type"

        conn.Close()

        str = " Select DISTINCT Site_QTY from PC_Status ORDER BY Site_QTY ASC"
        Dim adp3 As OleDbDataAdapter = New OleDbDataAdapter(str, conn)
        conn.Open()
        Dim set4 As DataSet = New DataSet
        adp3.Fill(set4, "#1")

        ComboBox4.DataSource = set4.Tables("#1")
        ComboBox4.ValueMember = "Site_QTY"
        conn.Close()

        str = "Select * from PC_Status where ([Status] Like 'BR') OR ([Status] Like 'F') ORDER BY Last_Use_Date DESC "
        Dim cmd As OleDbCommand = New OleDbCommand(str, conn)

        conn.Open()

        Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        Dim myDataSet As DataSet = New DataSet()
        myDA.Fill(myDataSet, "MyTable")
        DataGridView1.DataSource = myDataSet.Tables("MyTable").DefaultView

        'DataGridView1.Columns("Site_No").Visible = False

        DataGridView1.Columns("Vertical_Type").Width = 100
        DataGridView1.Columns("Status").Width = 50
        DataGridView1.Columns("Site_No").Width = 50
        DataGridView1.Columns("Tip_Len").Width = 80
        DataGridView1.Columns("Total_TD").Width = 80
        DataGridView1.Columns("TD_UPDATE_DATE").Width = 130
        DataGridView1.Columns("ETL_LOAD_DATE").Width = 130

        conn.Close()

        BP_Tester()

        Exit Sub
err:
        MsgBox("文件檔按錯誤")
        End

    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            RadioButton1.Checked = True
            RadioButton2.Checked = False
            TextBox1.Visible = False
            ComboBox2.Visible = True
            Label2.Text = "Family"
        Else
            RadioButton1.Checked = False
            RadioButton2.Checked = True
            TextBox1.Visible = True
            ComboBox2.Visible = False
            Label2.Text = "Parts_ID"
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            RadioButton2.Checked = True
            RadioButton1.Checked = False
            TextBox1.Visible = True
            ComboBox2.Visible = False
            Label2.Text = "Parts_ID"
        Else
            RadioButton2.Checked = False
            RadioButton1.Checked = True
            TextBox1.Visible = False
            ComboBox2.Visible = True
            Label2.Text = "Family"
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Application.Exit()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim myCon As New ADODB.Connection
        Dim myRst As New ADODB.Recordset

        Dim A(20) As String
        Dim g As Integer

        g = 1
        myCon = New Connection

        myCon.Open(sql)
        myRst = New Recordset


        If RadioButton1.Checked = True Then

            If CheckBox1.Checked = True Then
                str = "Select * from SPC where ([Family] Like '" & ComboBox2.Text & "%" & "') "
            Else
                str = "Select * from SPC where ([Family] Like '" & ComboBox2.Text & "') "
            End If

        ElseIf RadioButton2.Checked = True Then

            If CheckBox1.Checked = True Then
                str = "Select * from SPC where ([Parts_ID] Like '" & TextBox1.Text & "%" & "')"
            Else
                str = "Select * from SPC where ([Parts_ID] Like '" & TextBox1.Text & "')"
            End If
        End If


            myRst = myCon.Execute(str)


            Do While myRst.EOF = False
                MessageBox.Show("Parts_ID: " & myRst.Fields(2).Value & "  " & myRst.Fields(5).Value & "!!" & Chr(10) & "原因 : " & myRst.Fields(3).Value, "Warning message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                A(g) = myRst.Fields(2).Value
                myRst.MoveNext()
                g = g + 1
            Loop

            myCon.Close()
            ' myRst.Close()
            myRst = Nothing

            Dim conn As OleDbConnection = New OleDbConnection(sql)

        If RadioButton1.Checked = True Then

            If CheckBox1.Checked = True And ComboBox3.Text <> "" Then
                str = "Select * from PC_Status where ([Family] Like '" & ComboBox2.Text & "%" & "') AND ([Status] Like '" & ComboBox1.Text & "%" & "') AND ([Vertical_Type] Like '" & ComboBox3.Text & "%" & "') AND ([Site_Qty] Like '" & ComboBox4.Text & "%" & "') AND ([Site_No] Like '" & ComboBox5.Text & "%" & "')"
            ElseIf CheckBox1.Checked = False And ComboBox3.Text <> "" Then
                str = "Select * from PC_Status where ([Family] Like '" & ComboBox2.Text & "') AND ([Status] Like '" & ComboBox1.Text & "%" & "') AND ([Vertical_Type] Like '" & ComboBox3.Text & "%" & "') AND ([Site_Qty] Like '" & ComboBox4.Text & "%" & "') AND ([Site_No] Like '" & ComboBox5.Text & "%" & "')"
            ElseIf CheckBox1.Checked = True And ComboBox3.Text = "" Then
                str = "Select * from PC_Status where ([Family] Like '" & ComboBox2.Text & "%" & "') AND ([Status] Like '" & ComboBox1.Text & "%" & "') AND ([Site_Qty] Like '" & ComboBox4.Text & "%" & "') AND ([Site_No] Like '" & ComboBox5.Text & "%" & "')"
            ElseIf CheckBox1.Checked = False And ComboBox3.Text = "" Then
                str = "Select * from PC_Status where ([Family] Like '" & ComboBox2.Text & "') AND ([Status] Like '" & ComboBox1.Text & "%" & "') AND ([Site_Qty] Like '" & ComboBox4.Text & "%" & "') AND ([Site_No] Like '" & ComboBox5.Text & "%" & "')"

            End If


        ElseIf RadioButton2.Checked = True Then

            If CheckBox1.Checked = True And ComboBox3.Text <> "" Then
                str = "Select * from PC_Status where ([Parts_ID] Like '" & TextBox1.Text & "%" & "') AND ([Status] Like '" & ComboBox1.Text & "%" & "') AND ([Vertical_Type] Like '" & ComboBox3.Text & "%" & "') AND ([Site_Qty] Like '" & ComboBox4.Text & "%" & "') AND ([Site_No] Like '" & ComboBox5.Text & "%" & "')"
            ElseIf CheckBox1.Checked = False And ComboBox3.Text <> "" Then
                str = "Select * from PC_Status where ([Parts_ID] Like '" & TextBox1.Text & "') AND ([Status] Like '" & ComboBox1.Text & "%" & "') AND ([Vertical_Type] Like '" & ComboBox3.Text & "%" & "') AND ([Site_Qty] Like '" & ComboBox4.Text & "%" & "')AND ([Site_No] Like '" & ComboBox5.Text & "%" & "')"

            ElseIf CheckBox1.Checked = True And ComboBox3.Text = "" Then
                str = "Select * from PC_Status where ([Parts_ID] Like '" & TextBox1.Text & "%" & "') AND ([Status] Like '" & ComboBox1.Text & "%" & "') AND ([Site_Qty] Like '" & ComboBox4.Text & "%" & "') AND ([Site_No] Like '" & ComboBox5.Text & "%" & "')"

            ElseIf CheckBox1.Checked = False And ComboBox3.Text = "" Then
                str = "Select * from PC_Status where ([Parts_ID] Like '" & TextBox1.Text & "') AND ([Status] Like '" & ComboBox1.Text & "%" & "') AND ([Site_Qty] Like '" & ComboBox4.Text & "%" & "') AND ([Site_No] Like '" & ComboBox5.Text & "%" & "')"

            End If

        End If

            Dim cmd As OleDbCommand = New OleDbCommand(str, conn)
            conn.Open()
        Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "MyTable")
            DataGridView1.DataSource = myDataSet.Tables("MyTable").DefaultView

            conn.Close()

            Dim i As Integer
            Dim drv As DataGridViewRow

            For i = 0 To DataGridView1.Rows.Count - 1
                drv = DataGridView1.Rows(i)

                If (drv.Cells(3).FormattedValue = A(1)) Then drv.DefaultCellStyle.ForeColor = Color.Red
                If (drv.Cells(3).FormattedValue = A(2)) Then drv.DefaultCellStyle.ForeColor = Color.DarkGreen
                If (drv.Cells(3).FormattedValue = A(3)) Then drv.DefaultCellStyle.ForeColor = Color.DarkBlue
                If (drv.Cells(3).FormattedValue = A(4)) Then drv.DefaultCellStyle.ForeColor = Color.LightYellow
                If (drv.Cells(3).FormattedValue = A(5)) Then drv.DefaultCellStyle.ForeColor = Color.LightYellow
                If (drv.Cells(3).FormattedValue = A(6)) Then drv.DefaultCellStyle.ForeColor = Color.LightYellow
                'If (drv.Cells(3).FormattedValue <> "") And (drv.Cells(4).FormattedValue = "") Then drv.DefaultCellStyle.ForeColor = Color.Blue
                'If (drv.Cells(3).FormattedValue = "") And (drv.Cells(4).FormattedValue <> "") Then drv.DefaultCellStyle.ForeColor = Color.Green
        Next

        If CheckBox2.Checked = True Then
            BP_Tester()
        End If


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim excelApp As Excel.Application = New Excel.ApplicationClass
        Dim newWorksheet As Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim myCon As New ADODB.Connection
        Dim myRst As New ADODB.Recordset


        Dim i As Integer


        If RadioButton1.Checked = True Then
            str = "Select * from PC_Status where ([Family] Like '" & ComboBox2.Text & "%" & "') AND ([Status] Like '" & ComboBox1.Text & "%" & "') AND ([Vertical_Type] Like '" & ComboBox3.Text & "%" & "') AND ([Site_No] Like '" & ComboBox5.Text & "%" & "')"

        ElseIf RadioButton2.Checked = True Then
            str = "Select * from PC_Status where ([Parts_ID] Like '" & ComboBox2.Text & "%" & "') AND ([Status] Like '" & ComboBox1.Text & "%" & "')  AND ([Vertical_Type] Like '" & ComboBox3.Text & "%" & "') AND ([Site_No] Like '" & ComboBox5.Text & "%" & "') "
        End If

        myCon = New Connection

        myCon.Open(sql)
        myRst = New Recordset

        'strsql = "SELECT * From Receive_Table where " & ComboBox1.Text & " Like '%" & keywords & "%'"

        myRst = myCon.Execute(str)

        Try
            If myRst.EOF = True Then

                MsgBox("沒資料喔")
                myCon.Close()
            Else


                excelApp.DisplayAlerts = False ''停用警告訊息
                excelApp.Visible = False '設置EXCEL對象可見

                excelApp.Workbooks.Add()

                excelApp.Application.Sheets(1).Range("A1:J1").Interior.ColorIndex = 11
                excelApp.Application.Sheets(1).Range("A1:J1").Font.Bold = True
                excelApp.Application.Sheets(1).Range("A1:J1").Font.Color = RGB(255, 255, 255)
                excelApp.Application.Sheets(1).Range("A1").Value = "Vertical_Type"
                excelApp.Application.Sheets(1).Range("B1").Value = "PROCARD_TYPE"
                excelApp.Application.Sheets(1).Range("C1").Value = "Family"
                excelApp.Application.Sheets(1).Range("D1").Value = "Parts_ID"
                excelApp.Application.Sheets(1).Range("E1").Value = "ProbeHead_ID"
                excelApp.Application.Sheets(1).Range("F1").Value = "Status"
                excelApp.Application.Sheets(1).Range("G1").Value = "Site_No"
                excelApp.Application.Sheets(1).Range("H1").Value = "Location"
                excelApp.Application.Sheets(1).Range("I1").Value = "Tip_Len"
                excelApp.Application.Sheets(1).Range("J1").Value = "Total_TD"

                i = 2

                newWorksheet = excelApp.Application.Sheets(1)

                Do While Not myRst.EOF     '當資料指標未移到記錄集末尾時，迴圈下列操作

                    newWorksheet.Cells(i, 1) = myRst.Fields("Vertical_Type").Value    '把目前記錄的欄位1的值保存到sheet1工作表的第i行第1列
                    newWorksheet.Cells(i, 2) = myRst.Fields("PROCARD_TYPE").Value
                    newWorksheet.Cells(i, 3) = myRst.Fields("Family").Value
                    newWorksheet.Cells(i, 4) = myRst.Fields("Parts_ID").Value
                    newWorksheet.Cells(i, 5) = myRst.Fields("ProbeHead_ID").Value
                    newWorksheet.Cells(i, 6) = myRst.Fields("Status").Value
                    newWorksheet.Cells(i, 7) = myRst.Fields("Site_No").Value
                    newWorksheet.Cells(i, 8) = myRst.Fields("Location").Value
                    newWorksheet.Cells(i, 9) = myRst.Fields("Tip_Len").Value
                    newWorksheet.Cells(i, 10) = myRst.Fields("Total_TD").Value


                    myRst.MoveNext()                      '把指標移向下一條記錄
                    i = i + 1                        'i加1，準備把下一記錄相關欄位的值保存到工作表的下一行

                Loop


            End If


            excelApp.Application.Sheets(1).Columns("A:J").AutoFit()

            'newWorksheet.UsedRange.Borders.LineStyle = 1

            excelApp.Application.Sheets(1).Name = "PC_Status"

            Dim SaveDialog As New SaveFileDialog()
            SaveDialog.Filter = "Excel Files(*.xlsx)|*.xlsx|All files (*.*)|*.*"
            SaveDialog.FilterIndex = 2

            If SaveDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                excelApp.ActiveWorkbook.SaveAs(SaveDialog.FileName)
                MessageBox.Show("Export Successful")
            End If

            ' excelApp.ActiveWorkbook.SaveAs("d:\" & "PC_Status.xlsx")
            ' excelApp.DisplayAlerts = True
            ' excelApp.Quit()
            ' MessageBox.Show("匯出成功，查看D:\" & "PC_Status.xlsx", "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Information)


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally

            excelApp.Quit()
            GC.Collect()
            myCon.Close()

        End Try

    End Sub

    Sub delay()
        Dim Start As Integer = Environment.TickCount()
        Dim TimeLast As Integer = 300 ' 要延遲 t 秒,就設為 t *1000
        Do
            If Environment.TickCount() - Start > TimeLast Then Exit Do
            Application.DoEvents() ' 要記得寫這行，不然都在跑迴圈，畫面可能會不見
        Loop
    End Sub

    Private Sub 設定優先PartsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 設定優先PartsToolStripMenuItem.Click
        Form2.Show()
    End Sub

    Private Sub ver()
        Dim myCon As New ADODB.Connection
        Dim myRst As New ADODB.Recordset
        Dim v_no As String

        v_no = "21-06"
        myCon = New Connection

        myCon.Open(sql)
        myRst = New Recordset
        str = "Select * from Ver WHERE Ver_NO LIKE '" & v_no & "'"
        myRst = myCon.Execute(str)


        If myRst.EOF = True Then
            MessageBox.Show("程式版本已更新，請從Probe Card Tool 開啟。" & Chr(10) & "如有異常請通知管理者!!", "程式版本更新", MessageBoxButtons.OKCancel, MessageBoxIcon.Information)
            MenuStrip1.Enabled = False
            Close()
        End If

    End Sub

    Private Sub BP_Tester()
        Dim DBCon As OleDbConnection = New OleDbConnection(sql)

        str = "Select * From BP_ToTester where Family like '" & ComboBox2.Text & "%" & "' order by Family, Parts_ID, SITE_NO"
        Dim cmd As OleDbCommand = New OleDbCommand(str, DBCon)

        DBCon.Open()

        Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        Dim DBST As DataSet = New DataSet()
        myDA.Fill(DBST, "BP_ToTester")
        DBST.Tables("BP_ToTester").Columns.Remove("PARTS_NAME")
        DBST.Tables("BP_ToTester").Columns.Remove("B_STATUS")
        DBST.Tables("BP_ToTester").Columns.Remove("RETURN_TMP")
        'DBST.Tables("BP_ToTester").Columns.Remove("SITE_NO")
        DataGridView2.DataSource = DBST.Tables("BP_ToTester").DefaultView
        DBCon.Close()
        DBCon.Dispose()


    End Sub


End Class

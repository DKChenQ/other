﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
import win32com.client
#from win32com.client import Dispatch
from datetime import datetime

# 获取当前日期
today = datetime.today().strftime('%Y%m%d')

# 构造文件名
filename = f'D:\\{today}\\{today}_OEE.xlsx'
#filename = f'F:\\20230302_OEE.xlsx'

# 打开Excel文件
excel = win32com.client.Dispatch('Excel.Application')
excel.Visible = False # 隐藏Excel界面
workbook = excel.Workbooks.Open(filename, False)

# 选择Sheet4
worksheet = workbook.Worksheets('OEE By Family_FT')

# 删除第一行
worksheet.Rows(1).Delete()

# 保存修改后的文件
#workbook.Save()

# 另存新檔
new_filename = f'F:\\2023_LoadBoard_專用資料\\LB_OEE_FILE\\OEE.xlsx'
workbook.SaveAs(new_filename)

# 关闭Excel
excel.Quit()
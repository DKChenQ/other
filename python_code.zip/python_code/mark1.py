import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtChart import QChart, QChartView, QLineSeries, QScatterSeries, QValueAxis
from PyQt5.QtGui import QPainter
from PyQt5.QtCore import Qt

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        series = QLineSeries()
        series.append(0, 6)
        series.append(2, 4)
        series.append(3, 8)
        series.append(7, 4)
        series.append(10, 5)

        scatter = QScatterSeries()
        scatter.append(2, 4)
        scatter.append(3, 8)
        scatter.append(7, 4)

        chart = QChart()
        chart.addSeries(series)
        chart.addSeries(scatter)
        chart.createDefaultAxes()

        axis = QValueAxis()
        axis.setLabelFormat("%.1f")
        chart.setAxisY(axis, series)

        chart.setTitle("折線圖")
        chart.setAnimationOptions(QChart.SeriesAnimations)

        chartview = QChartView(chart)
        chartview.setRenderHint(QPainter.Antialiasing)

        self.setCentralWidget(chartview)

        for i in range(scatter.count()):
            x = scatter.at(i).x()
            y = scatter.at(i).y()
            label = "{:.1f}".format(y)
            chartview.chart().scene().addText(label, chartview.chart().mapToPosition(Qt.AlignCenter, x, y))

app = QApplication(sys.argv)
window = MainWindow()
window.show()
sys.exit(app.exec_())
#import pyodbc
#print(pyodbc.__version__)

import numpy
print(numpy.__file__)

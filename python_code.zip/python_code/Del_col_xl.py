#!/usr/bin/python
# -*- coding: utf-8 -*-

import openpyxl
from datetime import datetime

# 获取当前日期
today = datetime.today().strftime('%Y%m%d')

# 构造文件名
filename = f'D:\\{today}_OEE.xlsx'
#filename = f'20230301_OEE.xlsx'

# 打开Excel文件
workbook = openpyxl.load_workbook(filename)

# 选择Sheet4
worksheet = workbook['OEE By Family_FT']

# 删除第一行
worksheet.delete_rows(1)

# 保存修改后的文件
workbook.save(filename)
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtChart import QChart, QChartView, QLineSeries, QScatterSeries
from PyQt5.QtGui import QPainter
from PyQt5.QtCore import Qt

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        series = QLineSeries()
        series.append(0, 6)
        series.append(2, 4)
        series.append(3, 8)
        series.append(7, 4)
        series.append(10, 5)

        scatter = QScatterSeries()
        scatter.append(2, 4)

        chart = QChart()
        chart.addSeries(series)
        chart.addSeries(scatter)
        chart.createDefaultAxes()

        chartview = QChartView(chart)
        chartview.setRenderHint(QPainter.Antialiasing)

        self.setCentralWidget(chartview)

app = QApplication(sys.argv)
window = MainWindow()
window.show()
sys.exit(app.exec_())
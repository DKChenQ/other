#!/usr/bin/env python
# -*- coding: utf-8 -*-
import csv
import xlrd
import pyodbc
from datetime import datetime, timedelta

# 設置ODBC連接字串
conn_str = (
    r'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};'
    r'DBQ=F:\2023_LoadBoard_專用資料\ZK維修轉換\QCT_DataBase.accdb;'
    )

# 連接資料庫
conn = pyodbc.connect(conn_str)

#當天日期
#now_date = datetime.now()
now_date = datetime.now().strftime("%Y%m%d")

today = datetime.today()

# 篩選日期
date_15_days_ago = today - timedelta(days=0) #手動更改匯入
ch_date = date_15_days_ago.strftime('%Y%m%d')

# 格式化日期
in_date = date_15_days_ago.strftime('%Y-%m-%d')

#in_date = datetime.strftime(ch_date, "%Y-%m-%d")
print(in_date)

# 讀取Excel資料
excel_file = f'F:/2023_LoadBoard_專用資料/ZK維修轉換/Q_DATA/Load Board Status_SPIL_{ch_date}.xls'
workbook = xlrd.open_workbook(excel_file)
sheet = workbook.sheet_by_index(1)

# 指定Excel欄位索引
col_mapping = {'ExcelColumn1': 0, 'ExcelColumn2': 1, 'ExcelColumn3': 2, 'ExcelColumn4': 3, 'ExcelColumn5': 4, 'ExcelColumn6': 5, 'ExcelColumn7': 6, 'ExcelColumn8': 7,
               'ExcelColumn9': 8, 'ExcelColumn10': 9, 'ExcelColumn11': 10, 'ExcelColumn12': 11, 'ExcelColumn13': 12, 'ExcelColumn14': 13, 'ExcelColumn15': 14, 'ExcelColumn16': 15,
              'ExcelColumn17': 16, 'ExcelColumn18': 17, 'ExcelColumn19': 18, 'ExcelColumn20': 19}

# 將資料寫入Access資料庫
table_name = 'Qualcomm_Data'

# 定義INSERT語句
insert_sql = 'INSERT INTO Qualcomm_Data (CH_Date, SAT, Location, Device_Name, BODY_SIZE, PACKAGE_TYPE, Test_Type, DUT, GOOD_DUT, Tester_Platform, SAT_LB_Number, QCOM_LB_Number, Vendor, Owner, STATUS, Status_Date, SAT_Receive_Date, Plan_Send_date, Actual_Send_date, Expect_Return_date, Remark) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
#insert_sql = 'INSERT INTO Qualcomm_Data (CH_Date, SAT, Location, Device_Name, BODY_SIZE, PACKAGE_TYPE) VALUES (?, ?, ?, ?, ?, ?)'
cursor = conn.cursor()
for row_idx in range(2, sheet.nrows): #2是從第3列開始
    row = [in_date, #datetime.now(),  # 將日期作為第一個欄位值
           sheet.cell_value(row_idx, col_mapping['ExcelColumn1']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn2']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn3']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn4']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn5']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn6']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn7']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn8']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn9']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn10']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn11']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn12']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn13']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn14']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn15']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn16']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn17']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn18']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn19']),
           sheet.cell_value(row_idx, col_mapping['ExcelColumn20'])]
    cursor.execute(insert_sql, row)
conn.commit()

# 關閉資料庫連接
conn.close()


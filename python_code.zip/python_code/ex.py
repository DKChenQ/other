#!/usr/bin/python
# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
import pyodbc
import csv


#dbInst = 'EUC4DB-TW' # name of the oracle instance
#schema = 'AP_TCIM2HS'  # the oracle schema you will be using to login with
#passwd = '!IT2HS_00' # the password for the schema
#database ='EUC_E4_PMS_PART_BASIC_V'

#connString  = "ODBC;Driver={Oracle in OraClient11g_home1};Server=" + \
#dbInst + ';Uid=' + schema + ';Pwd=' + passwd + ';DBQ=' + database +";"
#connObj =  pyodbc.connect( connString )

#connObj.close

conString = (r'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=E:\Repair_Success_Rate.accdb;')
conn = pyodbc.connect(conString)

SQL = 'SELECT FORM_NO, PART_NO, CUSTOMER, FAMILY, R_STATUS, SITE_NO FROM Re_Su_Rate ORDER BY SITE_NO ASC, PART_NO'
cur = conn.cursor()
cur.execute(SQL)

# OPEN CSV AND ITERATE THROUGH RESULTS
with open('D:\\123.csv', 'w',encoding='utf-8',newline='' )as f: #+b移除空格
    writer = csv.writer(f) 
    writer.writerow(("From_NO", "Parts_ID", "Customer", "Family", "R_Status", "Site_No"))  
    for row in cur.fetchall():  
        writer.writerow(row)



frame = pd.DataFrame(np.random.random((4,4)),
                     index=['exp1','exp2','exp3','exp4'],
                     columns=['jan2015','Fab2015','Mar2015','Apr2005'])
print(frame)
frame.to_excel('d:\\data2.xlsx' , index=False)

df1 = pd.DataFrame([['a', 'b'], ['c', 'd']],
                   index=['row 1', 'row 2'],
                   columns=['col 1', 'col 2'])
df1.to_excel("d:\\output.xlsx")  
#!/usr/bin/python
# -*- coding: utf-8 -*-

import pyexcel as p
from win32com.client import Dispatch
xlapp = Dispatch('Excel.Application')
file_path = r'd:\PC_Status.xls'


# sheet = pyexcel.get_sheet(file_name="d:\PC_Status.csv", delimiter=",")
# sheet = pyexcel.get_sheet(sheet_name="PC_Status")

# sheet = pyexcel.get_sheet(file_name='d:\PC_Status.csv', delimiter=",")
# sheet.save_as(filename='d:\PC_Status.xls')

p.save_book_as(file_name='d:\PC_Status.csv',
               dest_file_name='d:\PC_Status.xls')

# 打開excel
xlbook = xlapp.Workbooks.Open(file_path, False)

xlbook.Close()
xlapp.Quit()

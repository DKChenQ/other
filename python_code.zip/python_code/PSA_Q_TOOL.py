#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import pyodbc
from PyQt5.QtWidgets import QApplication, QMainWindow, QComboBox, QLabel, QPushButton, QTableWidget, QTableWidgetItem, QCheckBox
from PyQt5.QtChart import QChart, QChartView, QLineSeries
from PyQt5.QtGui import QPainter,QFont
from PyQt5.QtCore import Qt,QRect


class App(QMainWindow):
    def __init__(self):
        super().__init__()
        self.title = 'PyQt5 Example'
        self.left = 10
        self.top = 10
        self.width = 1280
        self.height = 960

        # 連接Access資料庫
        self.conn = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=F:\2023_LoadBoard_專用資料\ZK維修轉換\QCT_DataBase.accdb;Uid=Admin;Pwd=;')
        self.cursor = self.conn.cursor()
        self.initUI()

    def closeEvent(self, event):
        # 視窗關閉時關閉資料庫連接
        self.conn.close()
        event.accept()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)

        # Adding labels
        self.label = QLabel(self)
        self.label.setGeometry(50, 10, 200, 50)
        self.label.setText("Device_Name:")
        self.label.setFont(QFont('Arial', 14))

        self.labe2 = QLabel(self)
        self.labe2.setGeometry(50, 80, 200, 50)
        self.labe2.setText("Tester_Platform:")
        self.labe2.setFont(QFont('Arial', 14))

        self.labe2 = QLabel(self)
        self.labe2.setGeometry(50, 80, 200, 50)
        self.labe2.setText("Tester_Platform:")
        self.labe2.setFont(QFont('Arial', 14))


        # Adding combo boxes
        # 建立combo1元件
        self.combo1 = QComboBox(self)
        self.combo1.setGeometry(QRect(50, 50, 250, 30))

        self.combo2 = QComboBox(self)
        self.combo2.setGeometry(QRect(50, 120, 250, 30))

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [Device_Name] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        for row in results:
            self.combo1.addItem(row[0])

        # 連接family資料表的欄位2資料
        self.cursor.execute("SELECT DISTINCT [Tester_Platform] FROM [Qualcomm_Data]")
        results = self.cursor.fetchall()
        for row in results:
            self.combo2.addItem(row[0])

        # Adding checkboxes
        checkbox1 = QCheckBox('Checkbox 1', self)
        checkbox1.move(50, 150)

        checkbox2 = QCheckBox('Checkbox 2', self)
        checkbox2.move(50, 180)

        checkbox3 = QCheckBox('Checkbox 3', self)
        checkbox3.move(50, 210)

        # Adding push button
        button = QPushButton('Button', self)
        button.move(50, 250)

        # Adding table widget
        table = QTableWidget(self)
        table.move(800, 600)
        table.setRowCount(4)
        table.setColumnCount(2)
        table.setHorizontalHeaderLabels(['Header 1', 'Header 2'])
        table.setVerticalHeaderLabels(['Row 1', 'Row 2', 'Row 3', 'Row 4'])
        table.setItem(0, 0, QTableWidgetItem('Item 1'))
        table.setItem(0, 1, QTableWidgetItem('Item 2'))

        # Adding curve chart
        series = QLineSeries()
        series.append(0, 6)
        series.append(2, 4)
        series.append(3, 8)
        series.append(7, 4)
        chart = QChart()
        chart.addSeries(series)
        chart.setTitle('Curve Chart')
        chart.createDefaultAxes()
        chart.legend().setVisible(True)
        chart.legend().setAlignment(Qt.AlignBottom)
        chart_view = QChartView(chart, self)
        chart_view.move(50, 300)
        chart_view.resize(600, 400)

        self.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = App()
    sys.exit(app.exec_())

#!/usr/bin/python
# -*- coding: utf-8 -*-
from openpyxl import load_workbook
from openpyxl import Workbook
#import openpyxl
wb = load_workbook('d:\11.xlsx')

wb = Workbook()
ws = wb.active
ws.title = "测试"
wb.save("d:\11.xlsx")

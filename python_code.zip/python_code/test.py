import csv
import os 
import xlrd
import xlwt

csvfiles = os.listdir('.')
csvfiles = filter(lambda x: x.endswith('csv'), csvfiles)
for csvfile in list(csvfiles):
    finename = csvfile.split('.')[0]
    if not os.path.exists('excel'):
        os.mkdir('excel')
xlsfile = 'excel/' + finename + '.xls'
with open(csvfile, 'r', encoding="utf-8", newline='') as f:
    reader = csv.reader(f)
    workbook = xlwt.Workbook()
    sheet = workbook.add_sheet('sheet1') #創建一個工作表
    i = 0
    for line in reader:
        j = 0
        for v in line:
            sheet.write(i, j, v)
            j += 1
        i += 1
    workbook.save(xlsfile) #儲存EXCEL
print(f'轉換完成: {csvfile} -> {xlsfile}')


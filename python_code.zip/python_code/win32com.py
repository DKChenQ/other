#!/usr/bin/python
# -*- coding: utf-8 -*-

from win32com.client import Dispatch
import pandas as pd
import numpy as np

xlapp = Dispatch('Excel.Application')
file_path = r'F:\\DK.xlsx'

# 打開excel
xlbook = xlapp.Workbooks.Open(file_path, False)

# 新建一個名為Aanlysis的worksheet
xlbook.Worksheets.Add().Name = 'Analysis'
sht_names = [sht.Name for sht in xlbook.Worksheets]
xlbook.Worksheets(2).Name = 'Details'

# 输出worksheets各数
print(xlbook.Worksheets.Count)

# 創建details worksheet對象
details = xlbook.Worksheets('Details')

# 獲取Excel Data的範圍
row = details.UsedRange.Rows.Count
col = details.UsedRange.Columns.Count

# 獲取單元格的值
print(details.Cells(2, 1).Value)

# 输出連續單元格的值
print(details.Range('A1:K1').Value)
print(details.Range(details.Cells(1, 1), details.Cells(1, 11)).Value)

analysis = xlbook.Worksheets('Analysis')
# 向Excel單元格中寫入内容
analysis.Range('A1').Value = 'Win32com On Excel'
values_write = list('abcDeF')
analysis.Range('A2:F2').Value = values_write
analysis.Range(analysis.Cells(3, 1), analysis.Cells(3, 6)
               ).Value = tuple(values_write)

# 清除内容
analysis.UsedRange.Clear()

# 獲取数據並創建DataFrame
# 獲取所有数據
details_value = list(details.Range(
    details.Cells(1, 2), details.Cells(row, col)).Value)

# 將details_value傳入Pandas中
details_df = pd.DataFrame(data=details_value[1:], columns=details_value[0])

# 使用Pandas進行分析
# 簡單分析
desc = details_df.describe(
    include=['object', 'number']).reset_index().T.reset_index()
r = desc.shape[0]
c = desc.shape[1]

# 獲取DataFrame的值並進行简單處理
# 获取值
desc_values = desc.values.tolist()

# A list can be inserted only if all of the numpy data types are the same
# and there is a built-in data type in the list as well
for i in range(len(desc_values)):
    for j in range(len(desc_values[i])):
        # print(type(desc_values[i][j]))
        if type(desc_values[i][j]) in [np.int32, np.int64, np.float32, np.float64]:
            desc_values[i][j] = np.float64(desc_values[i][j])

# 寫入Excel
analysis.Range(analysis.Cells(1, 1), analysis.Cells(r, c)).Value = desc_values
xlbook.Save()
xlbook.Close()
xlapp.Quit()

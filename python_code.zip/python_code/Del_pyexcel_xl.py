import pyexcel as pe
from datetime import datetime

# 获取当前日期
today = datetime.today().strftime('%Y%m%d')

# 构造文件名
filename = f'D:\\20230302_OEE.xlsx'

# 打开Excel文件
sheet = pe.get_sheet(file_name=filename)

# 删除第一行
sheet.delete_rows(0, 1)

# 保存修改后的文件
sheet.save_as(filename)
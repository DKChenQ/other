import numpy as np
import random


def draw_lose():
    range_ = input("請輸入號碼範圍: ex:1~49")
    range_ = np.array(range_.split("~")).astype(int)

    nums = input("輸入中獎數量:")
    nums = int(nums)

    results = random.sample(range(range_[0], range_[1]+1, nums))

    print("Bingo! 以下為中獎號碼:", results)
    return(results)


if __name__ == "__main__":
    draw_lose.run()

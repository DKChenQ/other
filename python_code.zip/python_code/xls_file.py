#!/usr/bin/python
# -*- coding: utf-8 -*-

# import pandas as pd
# import numpy as np
import pyodbc
# import cx_Oracle
import csv
# import win32com.client
# openpyxl import Workbook


# dbInst = 'EUC4DB-TW' # name of the oracle instance
# dbInst = 'Oracle in OraClient11g_home1_32bit' # name of the oracle instance
# schema = 'AP_TCIM2HS'  # the oracle schema you will be using to login with
# passwd = '!IT2HS_00' # the password for the schema
# database ='EUC4DB-TW'

# connString  = "ODBC;Driver={Oracle in OraClient11g_home1};Server=" + \

# connString  = "ODBC;Driver={Oracle in OraClient11g_home1_32bit};Server="+ dbInst + ';Uid=' + schema + ';Pwd=' + passwd + ';DBQ=' + database +";"
# connObj =  pyodbc.connect( connString )


conString = (
    r'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=E:\Repair_Success_Rate.accdb;')
conn = pyodbc.connect(conString)

# SQL = 'SELECT FORM_NO, PART_NO, CUSTOMER, FAMILY, R_STATUS, SITE_NO FROM Re_Su_Rate ORDER BY SITE_NO ASC, PART_NO'

# SQL = 'SELECT PART_CATEGORY, PART_TYPE, PART_NO, CUSTOMER, FAMILY, FORM_CATEGORY, FORM_TYPE, STATUS, COLUMN_NAME, COLUMN_VALUE, CREATE_TIME, SITE_NO FROM 維修成功率_測_TEMP ORDER BY SITE_NO ASC, PART_NO'

SQL = "SELECT EUC_E4_PMS_PART_BASIC_V.PART_NO, EUC_E4_PMS_PART_BASIC_V.PART_CATEGORY, EUC_E4_PMS_PART_BASIC_V.PART_TYPE, EUC_E4_PMS_PART_BASIC_V.SITE_NO" +\
    " FROM EUC_E4_PMS_PART_BASIC_V WHERE EUC_E4_PMS_PART_BASIC_V.PART_CATEGORY Like 'PROBECARD'"

# SQL = 'SELECT * FROM LoadBB'
cur = conn.cursor()
cur.execute(SQL)

# cur = connObj.cursor()
# cur.execute(SQL)


# OPEN CSV AND ITERATE THROUGH RESULTS
# OPEN CSV AND ITERATE THROUGH RESULTS
with open('D:\\123.csv', 'w', encoding='utf-8', newline='')as f:  # +b移除空格
    writer = csv.writer(f)
    # writer.writerow(("PART_CATEGORY", "PART_TYPE", "PART_NO", "CUSTOMER", "FAMILY", "FORM_CATEGORY", "FORM_TYPE", "STATUS", "COLUMN_NAME", "COLUMN_VALUE", "CREATE_TIME", "SITE_NO" ))
    writer.writerow(("PART_NO", "PART_CATEGORY", "PART_TYPE", "SITE_NO"))
    for row in cur.fetchall():
        writer.writerow(row)

cur.close()
conn.close()

# wb = Workbook()
# ws = wb.active

# connObj.close
# cur.close()

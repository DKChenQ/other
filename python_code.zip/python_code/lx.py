#!/usr/bin/python
# -*- coding: utf-8 -*-

# import pyodbc
# import numpy as np
# import pandas
import win32com.client


# 取得 Excel COMObject
excel = win32com.client.Dispatch('Excel.Application')

# 顯示視窗
excel.Visible = False

# 新增活頁簿
newBook = excel.Workbooks.Add()

# 取得目前的工作表
sheet = newBook.ActiveSheet

# 寫入資料
sheet.Cells(1, 1).Value = "Hello!"
sheet.Cells(1, 2).Value = "Excel."

# 儲存檔案
newBook.SaveAs("d:\\demo.xlsx")

# 關閉活頁簿
newBook.Close()

# 離開 Excel
excel.Application.Quit()

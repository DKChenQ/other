#!/usr/bin/python
# -*- coding: utf-8 -*-

import pyodbc
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side

# 连接到Access数据库
conn = pyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=F:\2023_LoadBoard_專用資料\CIM.accdb;')

# 從數據庫中選擇screw1表格
cursor = conn.cursor()
cursor.execute("SELECT * FROM CIM_SYSTEM")
rows = cursor.fetchall()

# 建立Excel文件并写入数据
wb = openpyxl.Workbook()
ws = wb.active

# 写入列标题
for col_num, column_title in enumerate(cursor.description, 1):
    c = ws.cell(row=1, column=col_num)
    c.value = column_title[0]
    c.fill = PatternFill("solid", fgColor="0070C0")
    c.font = Font(color="FFFFFF")
    c.alignment = Alignment(horizontal="center")
    c.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
    ws.column_dimensions[openpyxl.utils.get_column_letter(col_num)].width = 12
    

    
# 写入行数据
for row_num, row in enumerate(rows, 2):
    for col_num, cell_value in enumerate(row, 1):
        c = ws.cell(row=row_num, column=col_num)
        c.value = cell_value
        c.border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
    ws.row_dimensions[row_num].height = 16   


# 保存Excel文件
wb.save('F:\\2023_LoadBoard_專用資料\\CIM.xlsx')

# 关闭数据库连接
cursor.close()
conn.close()

#!/usr/bin/python
# -*- coding: utf-8 -*-

with open('D:\\test.txt','r') as f:
 data = f.read()
 print(data)

f.close()
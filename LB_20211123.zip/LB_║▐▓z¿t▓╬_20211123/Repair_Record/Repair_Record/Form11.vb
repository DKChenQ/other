﻿Imports System.Data.OleDb
Public Class Form11

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        If IsNumeric(TextBox1.Text) Or TextBox1.Text = "" Then
        Else
            MsgBox("請輸入數值")
            TextBox1.Text = ""
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click '確定
        ' Dim R As Integer '彈跳視窗宣告

        If Trim(TextBox1.Text) = "" Then
            MsgBox("請輸入數值")
        Else
            If CInt(TextBox1.Text) > Comp_QTY Then
                MessageBox.Show(" 領用數量不得大於目前數量 ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
       
                Received_QTY = CInt(TextBox1.Text) '領用數量
                Comp_QTY = Comp_QTY - Received_QTY '總數量-領用數量的變數
             

                If Change_Parts_List = "" Then
                    Change_Parts_List = COMP_Type_V & " * " & Received_QTY 'Change_Parts_List欄位顯示

                    COMP_Str = COMP_ID_V & ";" & Received_QTY & ";" & User_ID & ";" & Now & ";" & RV_CUSTOMER & ";" & RV_FAMILY & ";" & Comp_QTY 'COMP_Str 字串

                Else
                    Change_Parts_List = Change_Parts_List & " ; " & COMP_Type_V & " * " & Received_QTY 'Change_Parts_List欄位顯示
                    COMP_Str = COMP_Str & ";" & COMP_ID_V & ";" & Received_QTY & ";" & User_ID & ";" & Now & ";" & RV_CUSTOMER & ";" & RV_FAMILY & ";" & Comp_QTY 'COMP_Str 字串

                End If
            End If

            Form10.Change_Parts.Text = Change_Parts_List
            extend_save.txt_ChangeParts.Text = Change_Parts_List

            TextBox1.Text = ""
            Form10.Button3.PerformClick()
            Me.Close()


        End If

    End Sub

    Private Sub Form11_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.TopMost = True

    End Sub

End Class
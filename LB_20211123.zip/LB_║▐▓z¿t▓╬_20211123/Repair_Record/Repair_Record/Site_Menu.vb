﻿Public Class Site_Menu

    Dim S(33) As String
    Dim R(33) As String
    Dim Chk As CheckBox() = New CheckBox(33) {}

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Chk(0) = Me.CheckBox1
        Chk(1) = Me.CheckBox2
        Chk(2) = Me.CheckBox3
        Chk(3) = Me.CheckBox4
        Chk(4) = Me.CheckBox5
        Chk(5) = Me.CheckBox6
        Chk(6) = Me.CheckBox7
        Chk(7) = Me.CheckBox8
        Chk(8) = Me.CheckBox9
        Chk(9) = Me.CheckBox10
        Chk(10) = Me.CheckBox11
        Chk(11) = Me.CheckBox12
        Chk(12) = Me.CheckBox13
        Chk(13) = Me.CheckBox14
        Chk(14) = Me.CheckBox15
        Chk(15) = Me.CheckBox16
        Chk(16) = Me.CheckBox17
        Chk(17) = Me.CheckBox18
        Chk(18) = Me.CheckBox19
        Chk(19) = Me.CheckBox20
        Chk(20) = Me.CheckBox21
        Chk(21) = Me.CheckBox22
        Chk(22) = Me.CheckBox23
        Chk(23) = Me.CheckBox24
        Chk(24) = Me.CheckBox25
        Chk(25) = Me.CheckBox26
        Chk(26) = Me.CheckBox27
        Chk(27) = Me.CheckBox28
        Chk(28) = Me.CheckBox29
        Chk(29) = Me.CheckBox30
        Chk(30) = Me.CheckBox31
        Chk(31) = Me.CheckBox32
        Chk(32) = Me.CheckBox33
        Chk(33) = Me.CheckBox34


    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim i As Integer

        If Chk(33).Checked = True Then

            If Appion.txt_FailSite.Text = "" Then
                Appion.txt_FailSite.Text = Chk(33).Text
                Dim ALL_SITE As String = InputBox("請輸入SBin:", Chk(33).Text)
                Appion.txt_FailBin.Text = ALL_SITE
            End If
        Else

            For i = 0 To 32

                If Chk(i).Checked = True Then

                    If Appion.txt_FailSite.Text = "" Then
                        Appion.txt_FailSite.Text = Chk(i).Text

                        S(i) = InputBox("請輸入SBin:", Chk(i).Text)

                        R(i) = InputBox("請輸入Reason:", Chk(i).Text, Trim("Low Yield OR No Pass"))


                        If S(i) = Nothing Or R(i) = Nothing Then
                            Chk(i).Checked = False
                        Else
                            Appion.txt_FailBin.Text = S(i)
                            Appion.Cob_FailReason.Text = R(i)
                        End If
                    Else
                        Appion.txt_FailSite.Text = Appion.txt_FailSite.Text & "," & Chk(i).Text

                        S(i) = InputBox("請輸入SBin:", Chk(i).Text)
                        R(i) = InputBox("請輸入Reason:", Chk(i).Text, Trim("Low Yield OR No Pass"))

                        If S(i) = Nothing Or R(i) = Nothing Then
                            Chk(i).Checked = False
                        Else
                            Appion.txt_FailBin.Text = Appion.txt_FailBin.Text & "," & S(i)
                            Appion.Cob_FailReason.Text = Appion.Cob_FailReason.Text & "," & R(i)

                        End If

                    End If

                End If

            Next i

            QTY = i

        End If


        Appion.Cob_FailItem.Focus()
        Me.Close()

    End Sub


End Class
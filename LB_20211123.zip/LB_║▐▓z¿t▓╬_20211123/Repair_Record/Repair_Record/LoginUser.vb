﻿Imports System.Data.OleDb

Public Class LoginUser

    '建立資料庫連接
    Private DBCon As New OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;" & _
                                         "Data Source=" & Public_Path & "Register_Database.accdb;" & _
                                         "User Id=Admin;Jet OLEDB:Database Password=s967132 ;Persist Security Info=True")



    ' PREPARE DB COMMAND
    Private DBCmd As OleDbCommand

    'DB DATA
    Public DBDA As OleDbDataAdapter
    Public DBDT As DataTable
    Public DBST As DataSet

    Public Reader As OleDbDataReader


    'QUERY PARAMTERS
    Public Params As New List(Of OleDbParameter)


    Public RecordCount As Integer
    Public EXception As String

    Public Sub ExecQuery(ByVal Query As String)
        'RESET QUERY STATS
        RecordCount = 0
        EXception = ""

        Try
            'OPEN A CONNECTION
            DBCon.Open()

            'CRATE DB COMMAND
            DBCmd = New OleDbCommand(Query, DBCon)

            'LOAD PARAMS INTO DB COMMAND
            ' Params.ForEach(Sub(p) DBCmd.Parameters.Add(p))
            'Params.ForEach(Function(p) DBCmd.Parameters.Add(p))
            'CLEAR PARAMS LIST
            'Params.Clear()

            'EXECUTE COMMAND & FILL DATABLE
            DBDT = New DataTable
            DBDA = New OleDbDataAdapter(DBCmd)
            DBDA.Fill(DBDT)

            RecordCount = DBDA.Fill(DBDT)

            Reader = DBCmd.ExecuteReader

            'Dim i As Integer = Reader.FieldCount - 1
            ' While Reader.Read() = False

            ' End While

            If Reader.Read() = False Then

                MsgBox("無此ID或密碼錯誤")

            Else
                'Home_Screen.Show() '主畫面
                Home_Screen.Show()
                LoginForm1.Hide()

            End If

        Catch ex As Exception
            EXception = ex.Message
        End Try

        'CLOSE DB CONNECTION
        DBDA.Dispose()
        If DBCon.State = ConnectionState.Open Then DBCon.Close()


    End Sub

    Public Sub AddParams(ByVal Name As String, ByVal Value As Object)

        Dim NewParam As New OleDbParameter(Name, Value)
        Params.Add(NewParam)

    End Sub


End Class

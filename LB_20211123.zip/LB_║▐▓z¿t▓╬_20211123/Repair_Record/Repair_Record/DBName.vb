﻿Imports System.Data.OleDb

Module DBName



    'HOME
    Public OpenForm As Boolean
    Public EXception As String

    Public Version As String = "P1"
    Public User_Unit As String
    Public User_ID As String
    Public H_Z_Menu As String
    Public H_Z_DBCon As String

    'Appion
    Public A_Parts_ID, A_Customer, A_Family, A_Site_Qty, A_Tester_ID, A_Device, A_PGM, A_Stage As String  
    Public Close_Table As String


    Public DBDA As OleDbDataAdapter
    Public DBDT As DataTable
    Public DBST As DataSet

End Module

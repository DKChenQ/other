﻿Imports System.Data.OleDb

Public Class extend_save
    Private Comp As New Form10
    Dim conn As OleDbConnection = New OleDbConnection(H_Z_DBCon)
    Dim Str As String
    Dim Verify As String = "C" '完工 指標
    Dim RFL_Finish_Close As String

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click '暫存
        ' Close_Table = "1" '判斷Close 按鈕

        Dim Total_Time As Long
        Total_Time = DateDiff(DateInterval.Minute, R_Satrt_Time.Value, R_End_Time.Value)

        If Trim(txt_FailName.Text) = "" Or Trim(txt_Action.Text) = "" Or Trim(txt_RootCause.Text) = "" Or Trim(Cob_Attribute.Text) = "" Or Trim(txt_RepairManID.Text) = "" Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("欄位不得空白", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        ElseIf R_Satrt_Time.Value >= R_End_Time.Value Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("結束時間不得小於起始時間!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        ElseIf Cob_NowStatus.Text = "已結案" Then
            ' Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("Now_Status 已結案，不得未結案存檔!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        Else

            Close_Table = "1" '判斷Close 按鈕
            RFL_Finish_Close = "N"

            Dim U_R_Temp As String = " Update" & Repair_Fill_List_Table & "set Repair_Date_ST = '" & R_Satrt_Time.Value & "', Repair_Date_END = '" & R_End_Time.Value & "', Repair_Man = '" & txt_RepairManID.Text & "', Fail_Name ='" & txt_FailName.Text & "', Action_R = '" & txt_Action.Text & "', Root_Cause = '" & txt_RootCause.Text & "', Change_Parts = '" & txt_ChangeParts.Text & "', Attribute = '" & Cob_Attribute.Text & "', Final_Result = '" & Cob_FinalResult.Text & "', Now_Status = '" & Cob_NowStatus.Text & "', Total_Time = '" & Total_Time & "',  Finish_Close = '" & RFL_Finish_Close & "' where ID = " & RV_ID & " AND ID_Close = 'N'"

            conn.Open()
            Dim cmd As OleDbCommand = New OleDbCommand(U_R_Temp, conn)
            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()

            Comp.modify_comp_str() '扣除元件數量

            '顯示成功新增記錄的訊息()
            MessageBox.Show("儲存完成", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Me.Close()
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click '完工
        'Close_Table = "1" '判斷Close 按鈕

        Dim Total_Time As Long
        Total_Time = DateDiff(DateInterval.Minute, R_Satrt_Time.Value, R_End_Time.Value)

      
        If Trim(txt_FailName.Text) = "" Or Trim(txt_Action.Text) = "" Or Trim(txt_RootCause.Text) = "" Or Trim(Cob_Attribute.Text) = "" Or Trim(txt_RepairManID.Text) = "" Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("欄位不得空白", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        ElseIf Microsoft.VisualBasic.Right(Cob_FinalResult.Text, 4) <> "Pass" Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("Final_Result 非 PASS!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        ElseIf Cob_NowStatus.Text <> "已結案" Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("Now_Status 非 已結案!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        ElseIf R_Satrt_Time.Value >= R_End_Time.Value Then
            '  Close_Table = "0" '判斷Close 按鈕
            MessageBox.Show("結束時間不得小於起始時間!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        Else
            Close_Table = "1" '判斷Close 按鈕

            RFL_Finish_Close = "Y"

            Dim U_R_Temp As String = " Update" & Repair_Fill_List_Table & "set Repair_Date_ST = '" & R_Satrt_Time.Value & "', Repair_Date_END = '" & R_End_Time.Value & "', Repair_Man = '" & txt_RepairManID.Text & "', Fail_Name ='" & txt_FailName.Text & "', Action_R = '" & txt_Action.Text & "', Root_Cause = '" & txt_RootCause.Text & "', Change_Parts = '" & txt_ChangeParts.Text & "', Attribute = '" & Cob_Attribute.Text & "', Final_Result = '" & Cob_FinalResult.Text & "', Now_Status = '" & Cob_NowStatus.Text & "', Total_Time = '" & Total_Time & "',  Finish_Close = '" & RFL_Finish_Close & "', ID_Close = 'Y' where ID = " & RV_ID & " AND ID_Close = 'N'"

            conn.Open()

            Dim cmd1 As OleDbCommand = New OleDbCommand(U_R_Temp, conn)

            cmd1.ExecuteNonQuery()

            Str = " Update" & Fill_Data & "set Verify = '" & Verify & "' where ID = " & RV_ID & ""

            Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)

            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()
            Comp.modify_comp_str() '扣除元件數量
            '顯示成功新增記錄的訊息()
            MessageBox.Show("完成維修(DONE)", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Me.Close()
        End If

 


    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick

        Try
            Dim P_id As String = Lab_PartsID.Text.Substring(0, 4) & "%"
            Dim attri As String = DataGridView1.Rows(DataGridView1.CurrentCell.RowIndex).Cells(0).Value.ToString()

            Dim cmdText As String = "SELECT * FROM " & Repair_Done_List_V_Table & " WHERE Parts_ID LIKE @P_id AND Final_Result LIKE '%Pass' AND Fail_Bin LIKE @RV_FailBin AND Attribute = @attri"
            Dim cmd As OleDbCommand = New OleDbCommand(cmdText, conn)
            cmd.Parameters.AddWithValue("@P_id", P_id)
            cmd.Parameters.AddWithValue("@RV_FailBin", RV_FailBin)
            cmd.Parameters.AddWithValue("@attri", attri)

            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "MyTable")

            With DataGridView2
                .DataSource = myDataSet.Tables("MyTable").DefaultView
                .Columns("ID").Visible = False
                .Columns("Date_Time").Visible = False
                .Columns("Repair_Date_ST").Visible = False
                .Columns("Repair_Date_END").Visible = False
                .Columns("Parts_ID").Visible = True
                .Columns("Tester_ID").Visible = True
                .Columns("Customer").Visible = False
                .Columns("Family").Visible = False
                .Columns("Test_Mode").Visible = True
                .Columns("Send_Man").Visible = False
                .Columns("Fail_Item").Visible = False
                .Columns("Fail_Site").Visible = True
                .Columns("Fail_Bin").Visible = False
                .Columns("Repair_Site").Visible = False
                .Columns("Repair_Bin").Visible = False
                .Columns("Fail_Name").Visible = False
                .Columns("Action_R").Visible = False
                .Columns("Root_Cause").Visible = True
                .Columns("Change_Parts").Visible = True
                .Columns("Attribute").Visible = True
                .Columns("Final_Result").Visible = False
                .Columns("Now_Status").Visible = False
                .Columns("Total_Time").Visible = False
                .Columns("Finish_Close").Visible = False
            End With

        Catch ex As Exception
            ' handle exception here
        End Try


    End Sub

    Private Sub extend_save_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        If Close_Table = "1" Then '有存檔時執行
            HS_LoadBoard.Button6.PerformClick() ' 更新畫面
        Else
            Using conn As New OleDbConnection(H_Z_DBCon)
                conn.Open()
                Using cmd As New OleDbCommand()
                    ' 刪除 Repair_Fill_List_Table 中符合條件的資料
                    Str = "DELETE FROM " & Repair_Fill_List_Table & " WHERE ID LIKE " & RV_ID & " AND ID_Close = 'N'"
                    cmd.CommandText = Str
                    cmd.Connection = conn
                    cmd.ExecuteNonQuery()

                    ' 更新 Repair_Fill_List_Table 中符合條件的資料 ID_Close 為 'N'
                    Str = "UPDATE " & Repair_Fill_List_Table & " SET ID_Close = 'N' WHERE ID = " & RV_ID & " AND ID_N = " & RFL_ID_N & " -1 AND ID_Close = 'Y'"
                    cmd.CommandText = Str
                    cmd.ExecuteNonQuery()

                    ' 如果 Close_Table = "0"，則更新 Fill_Data 中符合條件的資料 Verify 為 'N'
                    If Close_Table = "0" Then
                        Str = "UPDATE " & Fill_Data & " SET Verify = 'N' WHERE ID = " & RV_ID
                        cmd.CommandText = Str
                        cmd.ExecuteNonQuery()
                    End If
                End Using
                conn.Close()
            End Using
            HS_LoadBoard.Button6.PerformClick() ' 更新畫面
        End If

    End Sub

    Private Sub Input_Table1()
        'Table input
        Try
            ' Attribute ComboBox
            Dim attributeQuery As String = "SELECT DISTINCT Item FROM Attribute"
            Dim attributeAdapter As New OleDbDataAdapter(attributeQuery, conn)
            Dim attributeSet As New DataSet()
            attributeAdapter.Fill(attributeSet, "Attribute")
            Cob_Attribute.DataSource = attributeSet.Tables("Attribute")
            Cob_Attribute.ValueMember = "Item"

            ' Now Status ComboBox
            Dim nowStatusQuery As String = "SELECT DISTINCT Item FROM Now_Status"
            Dim nowStatusAdapter As New OleDbDataAdapter(nowStatusQuery, conn)
            Dim nowStatusSet As New DataSet()
            nowStatusAdapter.Fill(nowStatusSet, "Now_Status")
            Cob_NowStatus.DataSource = nowStatusSet.Tables("Now_Status")
            Cob_NowStatus.ValueMember = "Item"

            ' Repair Man ID ComboBox
            Dim repairManQuery As String = "SELECT DISTINCT Man_ID FROM Man_List"
            Dim repairManAdapter As New OleDbDataAdapter(repairManQuery, conn)
            Dim repairManSet As New DataSet()
            repairManAdapter.Fill(repairManSet, "Man_List")
            txt_RepairManID.DataSource = repairManSet.Tables("Man_List")
            txt_RepairManID.ValueMember = "Man_ID"
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try

        Cob_FinalResult.Items.Add("Online Pass")
        Cob_FinalResult.Items.Add("Online Fail")
        Cob_FinalResult.Items.Add("Offline Pass")
        Cob_FinalResult.Items.Add("Offline Fail")

    End Sub

    Private Sub txt_ChangeParts_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txt_ChangeParts.MouseDoubleClick '更換元件欄位
        txt_ChangeParts.Text = ""
        Change_Parts_List = ""
        COMP_Str = ""
        Form10.Show()
    End Sub


    Private Sub Cob_NowStatus_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cob_NowStatus.SelectedIndexChanged

        Cob_Attribute.Enabled = Cob_NowStatus.Text <> "待維修"
        Cob_Attribute.SelectedIndex = If(Cob_NowStatus.Text = "待維修", 0, Cob_Attribute.SelectedIndex)

    End Sub

    Private Sub Cob_Attribute_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cob_Attribute.SelectedValueChanged

        txt_ChangeParts.Enabled = Arr_Attribute(Cob_Attribute.SelectedIndex)


    End Sub
End Class
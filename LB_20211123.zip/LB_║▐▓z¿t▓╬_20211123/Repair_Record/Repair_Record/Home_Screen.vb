﻿Imports System.Data.OleDb


Public Class Home_Screen

    Private Sub AppionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AppionToolStripMenuItem.Click '建立維修單
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If OpenForm = False Then
            OpenForm = True
            Appion.MdiParent = Me

            If User_Unit = "LB_HS" Or User_Unit = "LB_ZK" Or User_Unit = "LB_EL" Or User_Unit = "LB_TEST" Or User_Unit = "LB_ADMIN" Then
                Appion.Cob_Unit.Items.Add("")
                Appion.Cob_Unit.Items.Add("L/B")

            ElseIf User_Unit = "CP" Or User_Unit = "LB_ADMIN" Then
                Appion.Cob_Unit.Items.Add("")
                Appion.Cob_Unit.Items.Add("CP")

            End If

            Appion.Show()
        Else
            MsgBox("請先離開本表單" & vbCrLf & "Exit this form,please", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Message")
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub

    Private Sub ReceiveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReceiveToolStripMenuItem.Click '填寫維修單

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If OpenForm = False Then
            OpenForm = True
            HS_LoadBoard.MdiParent = Me

            HS_LoadBoard.Show()

        Else
            MsgBox("請先離開本表單" & vbCrLf & "Exit this form,please", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Message")
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default


    End Sub

    Private Sub ComponentControlToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComponentControlToolStripMenuItem.Click
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If OpenForm = False Then
            OpenForm = True

            Component_Control.MdiParent = Me

            Component_Control.Show()

        Else
            MsgBox("請先離開本表單" & vbCrLf & "Exit this form,please", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Message")
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default


    End Sub

    Private Sub Home_Screen_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        End

    End Sub

    Private Sub DutBoardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DutBoardToolStripMenuItem.Click

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If OpenForm = False Then
            OpenForm = True

            Dutboard.MdiParent = Me

            Dutboard.Show()

        Else
            MsgBox("請先離開本表單" & vbCrLf & "Exit this form,please", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Message")
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

    End Sub

    Private Sub EditFailCodeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditFailCodeToolStripMenuItem.Click
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        If OpenForm = False Then
            OpenForm = True

            DutBoard_Fail_Code.MdiParent = Me

            DutBoard_Fail_Code.Show()

        Else
            MsgBox("請先離開本表單" & vbCrLf & "Exit this form,please", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Message")
        End If

        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
    End Sub

    Private Sub Home_Screen_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If User_Unit = "LB_ZK" Or User_Unit = "LB_EL" Or User_Unit = "LB_TEST" Then

            DutBoardDToolStripMenuItem.Enabled = True
        Else
            DutBoardDToolStripMenuItem.Enabled = False

        End If

    End Sub
End Class

﻿Public Class Table_Form_Boolean

    Public FORM10_OFF_ON As String
    Public FORM8_OFF_ON As String






End Class

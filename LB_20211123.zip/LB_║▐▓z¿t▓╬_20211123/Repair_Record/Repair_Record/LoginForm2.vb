﻿Imports System.Windows.Forms
Imports System.Data
Imports System.Data.OleDb
Imports ADODB
Imports Microsoft.Office.Interop

Public Class LoginForm2
    Dim sql As String = Register_Database

    Dim myCon As New ADODB.Connection
    Dim myRst As New ADODB.Recordset

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click

        If UsernameTextBox.Text = "" Or PasswordTextBox.Text = "" Then
            MessageBox.Show("使用者工號 或 密碼 不得空白", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Dim str As String = "Select * from" & UserN & "where Name_ID like '" & UsernameTextBox.Text & "' and Name_P like '" & PasswordTextBox.Text & "' "

            myCon = New Connection

            myCon.Open(sql)
            myRst = New Recordset

            Dim strql As String = "Select * from" & UserN & "where Name_ID like '" & UsernameTextBox.Text & "' and Name_P like '" & PasswordTextBox.Text & "' "

            myRst = myCon.Execute(strql)

            If myRst.EOF = True Then

                MessageBox.Show("使用者名稱或密碼錯誤", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                myCon.Close()

            Else
                Dim conn As OleDbConnection = New OleDbConnection(sql)

                Dim str2 As String = "Update" & UserN & "set Name_P = '" & TextBox1.Text & "' where Name_ID Like '" & UsernameTextBox.Text & "'"

                Dim cmd2 As OleDbCommand = New OleDbCommand(str2, conn)

                conn.Open()
                '執行資料庫指令OleDbCommand
                cmd2.ExecuteNonQuery()

                '關閉資料庫的連結
                conn.Close()

                myCon.Close()

                MessageBox.Show("密碼更新完成", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Me.Close()
                LoginForm1.Show()

            End If

        End If

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub LoginFrom2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        LoginForm1.Show()
    End Sub

End Class

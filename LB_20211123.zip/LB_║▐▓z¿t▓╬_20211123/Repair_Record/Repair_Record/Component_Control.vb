﻿Imports System.IO.Ports
Imports System.Threading
Imports System.Data
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Imports ADODB

Public Class Component_Control
    Dim sql As String = Componet_DataBase
    Dim Str As String
    Dim conn As OleDbConnection = New OleDbConnection(sql)

    Public Sub Comp_ReLoard()

        Str = "Select * from List_Table order by Spec_Type desc" 'where Status Like 'F' and isnull(Fail_Close)"
        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
        conn.Open()
        Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        Dim myDataSet As DataSet = New DataSet()
        myDA.Fill(myDataSet, "MyTable")
        DataGridView1.DataSource = myDataSet.Tables("MyTable").DefaultView
        conn.Close()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click '新增
        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
        Dim SPEC As String
        On Error GoTo ERR

        If Len(txt_SpilNo.Text) >= 1 And Len(txt_SpilNo.Text) < 9 Then
            MessageBox.Show(" SPIL_No 需為9碼..請確認! ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf Cob_Size.Text <> "" And Trim(txt_Volt.Text) = "" And Trim(txt_Tolerance.Text) = "" Then
            MessageBox.Show(" 已選擇SIZE 規格, Vlot & Tolerance(%) 是必須填寫!! ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf Cob_Size.Text = "" And Trim(txt_Volt.Text) <> "" And Trim(txt_Tolerance.Text) <> "" Then
            MessageBox.Show(" 未選擇SIZE 規格, Vlot & Tolerance(%) 不需填寫!! ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            If Cob_Size.Text = "" And Trim(txt_Volt.Text) = "" And Trim(txt_Tolerance.Text) = "" Then
                SPEC = txt_Spec.Text
            Else
                SPEC = Cob_Size.Text & "_" & txt_Spec.Text & "_" & txt_Volt.Text & "_" & txt_Tolerance.Text
                MsgBox(SPEC)
            End If

            Str = "Insert Into List_Table(SPIL_No, Vendor_Name, Vendor_No, Customer, Family, Kind, Spec_Type, Qty, Provider, Creator, Creator_Date, Location, Spare_Qty )Values" & _
                                        "( '" & txt_SpilNo.Text & "' , '" & txt_VendorName.Text & "' , '" & txt_VendorNo.Text & "' , '" & txt_Customer.Text & "' , '" & txt_Family.Text & "' , '" & Cob_Kind.Text & "' , '" & SPEC & "' , '" & txt_Qty.Text & "' , '" & Cob_Provider.Text & "' , '" & User_ID & "' , '" & Now & "', '" & txt_Location.Text & "', '" & txt_SperQty.Text & "')"

            ' Dim conn As OleDbConnection = New OleDbConnection(sql)
            conn.Open()

            cmd = New OleDbCommand(Str, conn)

            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()

            MessageBox.Show(" Done.. ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Box_Clean()
            Comp_ReLoard()
        End If

        Exit Sub
ERR:
        MessageBox.Show(" SPIL_No 重複, 請確認!  ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        conn.Close()
    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        Dim row As DataGridViewRow = DataGridView1.CurrentRow
        'Dim C_ID As Long
        Dim Split_Spec() As String
        Dim k0, k1, k2, k3 As Integer
        On Error Resume Next
        Comp_ID = CLng(row.Cells(0).Value.ToString())
        txt_SpilNo.Text = row.Cells(1).Value.ToString()
        txt_VendorName.Text = row.Cells(2).Value.ToString()
        txt_VendorNo.Text = row.Cells(3).Value.ToString()
        txt_Customer.Text = row.Cells(4).Value.ToString()
        txt_Family.Text = row.Cells(5).Value.ToString()
        Cob_Kind.Text = row.Cells(6).Value.ToString()
        Split_Spec = Split(row.Cells(7).Value.ToString(), "_")
        k0 = Len(Split_Spec(0))
        k1 = Len(Split_Spec(1))
        k2 = Len(Split_Spec(2))
        k3 = Len(Split_Spec(3))

        If k0 <> 0 Then
            Cob_Size.Text = Split_Spec(0)
        End If
        If k1 <> 0 Then
            txt_Spec.Text = Split_Spec(1)
        End If
        If k2 <> 0 Then
            txt_Volt.Text = Split_Spec(2)
        End If
        If k3 <> 0 Then
            txt_Tolerance.Text = Split_Spec(3)
        End If
        txt_Qty.Text = row.Cells(8).Value.ToString()
        Cob_Provider.Text = row.Cells(9).Value.ToString()
        txt_Location.Text = row.Cells(12).Value.ToString()
        txt_SperQty.Text = row.Cells(13).Value.ToString()

    End Sub

    Private Sub Box_Clean()

        txt_SpilNo.Clear()
        txt_VendorName.Clear()
        txt_VendorNo.Clear()
        txt_Customer.Clear()
        txt_Family.Clear()
        Cob_Kind.Text = ""
        Cob_Size.Text = ""
        txt_Spec.Clear()
        txt_Volt.Clear()
        txt_Tolerance.Clear()
        txt_Qty.Clear()
        Cob_Provider.Text = ""
        txt_Location.Clear()
        txt_SperQty.Clear()

    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click '修改

        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
        Dim SPEC, T1 As String
        On Error GoTo ERR ' 需修改SPIL_NO.

        If Len(Trim(txt_SpilNo.Text)) >= 1 And Len(Trim(txt_SpilNo.Text)) < 9 Then
            MessageBox.Show(" SPIL_No 需為9碼..請確認! ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf Cob_Size.Text <> "" And Trim(txt_Volt.Text) = "" And Trim(txt_Tolerance.Text) = "" Then
            MessageBox.Show(" 已選擇SIZE 規格, Vlot & Tolerance(%) 是必須填寫!! ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf Cob_Size.Text = "" And Trim(txt_Volt.Text) <> "" And Trim(txt_Tolerance.Text) <> "" Then
            MessageBox.Show(" 未選擇SIZE 規格, Vlot & Tolerance(%) 不需填寫!! ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            If Cob_Size.Text = "" And Trim(txt_Volt.Text) = "" And Trim(txt_Tolerance.Text) = "" Then
                SPEC = txt_Spec.Text
            Else
                SPEC = Cob_Size.Text & "_" & txt_Spec.Text & "_" & txt_Volt.Text & "_" & txt_Tolerance.Text
            End If

            If Trim(txt_SpilNo.Text) = "" Then
                If Len(Comp_ID.ToString) = 1 Then
                    T1 = "P0000000" & Comp_ID
                ElseIf Len(Comp_ID.ToString) = 2 Then
                    T1 = "P000000" & Comp_ID
                ElseIf Len(Comp_ID.ToString) = 3 Then
                    T1 = "P00000" & Comp_ID
                ElseIf Len(Comp_ID.ToString) = 4 Then
                    T1 = "P0000" & Comp_ID
                ElseIf Len(Comp_ID.ToString) = 5 Then
                    T1 = "P000" & Comp_ID
                ElseIf Len(Comp_ID.ToString) = 6 Then
                    T1 = "P00" & Comp_ID
                ElseIf Len(Comp_ID.ToString) = 7 Then
                    T1 = "P0" & Comp_ID
                ElseIf Len(Comp_ID.ToString) = 8 Then
                    T1 = "P" & Comp_ID
                End If
            Else
                T1 = txt_SpilNo.Text
            End If

            Str = "Update List_Table set SPIL_No = '" & T1 & "' , Vendor_Name = '" & txt_VendorName.Text & "' , Vendor_No = '" & txt_VendorNo.Text & "', Customer = '" & txt_Customer.Text & "', Family = '" & txt_Family.Text & "', Kind =  '" & Cob_Kind.Text & "', Spec_Type = '" & SPEC & "', Qty = '" & txt_Qty.Text & "', Provider = '" & Cob_Provider.Text & "', Creator = '" & User_ID & "', Creator_Date = '" & Now & "', Location= '" & txt_Location.Text & "', Spare_Qty = '" & txt_SperQty.Text & "' where ID = " & Comp_ID & ""

            conn.Open()

            cmd = New OleDbCommand(Str, conn)

            '執行資料庫指令OleDbCommand
            cmd.ExecuteNonQuery()
            conn.Close()

            MessageBox.Show(" Done.. ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Box_Clean()
            Comp_ReLoard()
        End If

        Exit Sub
ERR:

        MessageBox.Show(" SPIL_No 重複, 請確認!  ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        conn.Close()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click '查詢

        Str = "Select * from List_Table where Spec_Type Like  '%' & '" & TextBox12.Text & "' & '%' " 'where Status Like 'F' and isnull(Fail_Close)"
        Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
        conn.Open()
        Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
        Dim myDataSet As DataSet = New DataSet()
        myDA.Fill(myDataSet, "MyTable")
        DataGridView2.DataSource = myDataSet.Tables("MyTable").DefaultView
        conn.Close()

    End Sub

    Private Sub DataGridView2_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView2.CellMouseClick

        Dim row As DataGridViewRow = DataGridView2.CurrentRow

        Comp_ID = CLng(row.Cells(0).Value.ToString())
        Form17.Text = row.Cells(7).Value.ToString()
        Comp_QTY = row.Cells(8).Value.ToString()

        Form17.Show()

    End Sub


    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click  '領用查詢
        Dim st, et As String

        st = "#" & Format(DateTimePicker1.Value, "yyyy/MM/dd 00:00:00") & "#"
        et = "#" & Format(DateTimePicker2.Value, "yyyy/MM/dd 23:59:59") & "#"

        If st > et Then
            MessageBox.Show("起始日期大於結束日期!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else

            Str = "Select * from Consume_Data where Consume_Date Between " & st & " and " & et & " " 'where Status Like 'F' and isnull(Fail_Close)"
            Dim cmd As OleDbCommand = New OleDbCommand(Str, conn)
            conn.Open()
            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "MyTable")
            DataGridView3.DataSource = myDataSet.Tables("MyTable").DefaultView
            conn.Close()
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click '匯出
        Dim excelApp As Excel.Application = New Excel.ApplicationClass()
        Dim NewWorksheet As Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim myCon As New ADODB.Connection
        Dim myRst As New ADODB.Recordset
        Dim ST, EN As String
        Dim I As Long

        ST = "#" & Format(DateTimePicker1.Value, "yyyy/MM/dd 00:00:00") & "#"
        EN = "#" & Format(DateTimePicker2.Value, "yyyy/MM/dd 23:59:59") & "#"

        myCon = New Connection

        myCon.Open(sql)

        myRst = New Recordset

        Dim Str As String = "Select * from Consume_Data where Consume_Date Between " & ST & " and " & EN & ""
        'Dim Str As String = "Select * from Data_Edit_Test where ([是否完成] Like '是') "
        myRst = myCon.Execute(Str)

        If myRst.EOF = True Then

            MsgBox("沒資料喔")
            myCon.Close()
        Else

            excelApp.DisplayAlerts = False ''停用警告訊息
            excelApp.Visible = False '設置EXCEL對象可見

            excelApp.Workbooks.Add()
            NewWorksheet = excelApp.Application.Sheets(1)

            NewWorksheet.Range("A1:G1").Interior.Color = RGB(255, 192, 0)
            NewWorksheet.Range("A1:G1").Font.Bold = True
            NewWorksheet.Range("A1:G1").Font.Color = RGB(128, 128, 128)
            NewWorksheet.Range("A1").Value = "SPIL_No"
            NewWorksheet.Range("B1").Value = "客戶"
            NewWorksheet.Range("C1").Value = "型號"
            NewWorksheet.Range("D1").Value = "類別"
            NewWorksheet.Range("E1").Value = "規格"
            NewWorksheet.Range("F1").Value = "數量"
            NewWorksheet.Range("G1").Value = "領用日期"

            i = 2

            Do While Not myRst.EOF     '當資料指標未移到記錄集末尾時，迴圈下列操作

                NewWorksheet.Cells(i, 1) = myRst.Fields("SPIL_No").Value    '把目前記錄的欄位1的值保存到sheet1工作表的第i行第1列
                NewWorksheet.Cells(i, 2) = myRst.Fields("Consume_Customer").Value
                NewWorksheet.Cells(i, 3) = myRst.Fields("Consume_Family").Value
                NewWorksheet.Cells(i, 4) = myRst.Fields("Kind").Value
                NewWorksheet.Cells(i, 5) = myRst.Fields("Spec_Type").Value
                NewWorksheet.Cells(i, 6) = myRst.Fields("Consume_Qty").Value
                NewWorksheet.Cells(i, 7) = myRst.Fields("Consume_Date").Value


                myRst.MoveNext()                      '把指標移向下一條記錄
                i = i + 1                        'i加1，準備把下一記錄相關欄位的值保存到工作表的下一行

                NewWorksheet.Columns("A:G").AutoFit()
                NewWorksheet.UsedRange.Borders.LineStyle = 1

            Loop

            NewWorksheet.Name = "元件領用資料"

            excelApp.ActiveWorkbook.SaveAs("D:\" & Format(Now, "yyyyMMdd") & "_" & "元件領用資料.xlsx")
            excelApp.DisplayAlerts = True
            excelApp.Quit()

            myCon.Close()
            MessageBox.Show("匯出成功，查看D:\" & Format(Now, "yyyyMMdd") & "_" & "元件領用資料.xlsx", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If


    End Sub
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click '修改

        txt_SpilNo.Text = ""
        txt_VendorName.Text = ""
        txt_VendorNo.Text = ""
        txt_Customer.Text = ""
        txt_Family.Text = ""
        Cob_Kind.Text = ""
        Cob_Size.Text = ""
        txt_Spec.Text = ""
        txt_Volt.Text = ""
        txt_Tolerance.Text = ""
        txt_Qty.Text = ""
        Cob_Provider.Text = ""
        txt_Location.Text = ""
        txt_SperQty.Text = ""

    End Sub

    Private Sub Component_Control_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Dim cmd As OleDbCommand
        Dim reader As OleDbDataReader

        Str = "Select DISTINCT Item from Kind_Table" ' where Parts_ID Like '" & HFTV_Parts_ID & "'"

        cmd = New OleDbCommand(Str, conn)
        conn.Open()
        reader = cmd.ExecuteReader

        While reader.Read()
            Cob_Kind.Items.Add(reader.Item("Item").ToString)
        End While
        conn.Close()
        Str = "Select DISTINCT Size_Name from Size_Table" ' where Parts_ID Like '" & HFTV_Parts_ID & "'"
        cmd = New OleDbCommand(Str, conn)
        conn.Open()
        reader = cmd.ExecuteReader

        While reader.Read()
            Cob_Size.Items.Add(reader.Item("Size_Name").ToString)
        End While
        conn.Close()

        Str = "Select DISTINCT Provider from Provider_Table" ' where Parts_ID Like '" & HFTV_Parts_ID & "'"

        cmd = New OleDbCommand(Str, conn)
        conn.Open()
        reader = cmd.ExecuteReader

        While reader.Read()
            Cob_Provider.Items.Add(reader.Item("Provider").ToString)
        End While
        conn.Close()

        Comp_ReLoard()

    End Sub

    Private Sub Component_Control_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If OpenForm = True Then OpenForm = False : Exit Sub
        conn.Dispose()
    End Sub



End Class